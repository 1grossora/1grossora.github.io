# Hello Reader

There is a Notebook located in the run directory called Exploratory.ipynb which has most of the code in it. 

There is also come helper code in the apps directory

The data is located in the data directory 

There are also some useful pdf documents in the pdfs dir. 

If you have any questions all my forms of contact are located on my webpage 

www.ryangrosso.com



