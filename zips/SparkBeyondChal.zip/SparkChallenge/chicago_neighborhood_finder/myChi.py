import sys, os
from chicago_community_areas import (get_neighborhood_for_point,get_community_area_coords,download_shapefiles)


#print ' here '
self = get_community_area_coords()
res = get_neighborhood_for_point(41.8703314, -87.6235742, self)
print res
