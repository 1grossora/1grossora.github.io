import numpy as np 

def closest_station_id(inlat, inlon):
    '''
    input lat and lon
    returns station id that is cloest to input latlon
    '''
    #Station 1: CHICAGO O'HARE INTERNATIONAL AIRPORT Lat: 41.995 Lon: -87.933
    #Station 2: CHICAGO MIDWAY INTL ARPT Lat: 41.786 Lon: -87.752
    s1_lat = 41.995
    s1_lon = -87.933
    s2_lat = 41.786
    s2_lon = -87.752

    s1_dist_sq = (inlat-s1_lat)**2 +( inlon-s1_lon)**2
    s2_dist_sq = (inlat-s2_lat)**2 +( inlon-s2_lon)**2


    if s1_dist_sq < s2_dist_sq:
        return 1
    else: 
        return 2

    
