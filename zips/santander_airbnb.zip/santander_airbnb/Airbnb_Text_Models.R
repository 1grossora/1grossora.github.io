library(SparkBeyond)
login(
  username = 'youremail@email.com', 
  password = 'your_passphrase', 
  url = 'https://sparkbeyond_server_url.com'
)


# Load in data
traindata = read.csv("~/Downloads/santander_airbnb/airbnb_nyc_text.csv", header = TRUE)

#Baseline with text data
model_geo_control = SparkBeyond::learn(
  projectName = "Airbnb_R_Primary",
  trainData = traindata,
  target = "PRICE",
  featureGeneration = featureGenerationControl(
    allowRangeFeatures = FALSE,numericEqualityFeatures = FALSE,equalityFeatures = FALSE, 
    functionsBlackList = list('consecutiveCharactersText','punctuationRatio','upperCaseRatio','letterUpperCaseRatio')
  ),
  revisionDescription = 'text_baseline', 
  run_blocking = FALSE
)

#Baseline with text data
model_geo_control = SparkBeyond::learn(
  projectName = "Airbnb_R_Primary",
  trainData = traindata,
  target = "PRICE",
  featureGeneration = featureGenerationControl(
    allowRangeFeatures = FALSE,numericEqualityFeatures = FALSE,equalityFeatures = FALSE, 
    functionsBlackList = list('consecutiveCharactersText','punctuationRatio','upperCaseRatio','letterUpperCaseRatio')
  ),
  knowledge = knowledgeControl(linkedDataCore = TRUE),
  revisionDescription = 'text_baseline', 
  run_blocking = FALSE
)
