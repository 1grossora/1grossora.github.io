library(SparkBeyond)
#login(
#  username = 'youremail@email.com', 
#  password = 'your_passphrase', 
#  url = 'https://sparkbeyond_server_url.com'
#)

login(
  username = 'Ryan.grosso@sparkbeyond.com', 
  password = 'Raiders72!', 
  url = 'https://training2.sparkbeyond.com'
)

# Load in data
traindata = read.csv("~/Downloads/santander_airbnb/airbnb_nyc_geo.csv", header = TRUE)

#Baseline with geospatial data
model_geo_control = SparkBeyond::learn(
  projectName = "Airbnb_R_Primary",
  trainData = traindata,
  target = "PRICE",
  featureGeneration = featureGenerationControl(
    allowRangeFeatures = FALSE,numericEqualityFeatures = FALSE,equalityFeatures = FALSE, 
    functionsBlackList = list('consecutiveCharactersText','punctuationRatio','upperCaseRatio','letterUpperCaseRatio')
    ),
  revisionDescription = 'Geo_baseline', 
  run_blocking = FALSE
)


#adding Geospatial context
model_geo_control_geo_context = SparkBeyond::learn(
  projectName = "Airbnb_R_Primary",
  trainData = traindata,
  target = "PRICE",
  featureGeneration = featureGenerationControl(allowRangeFeatures = FALSE,numericEqualityFeatures = FALSE,equalityFeatures = FALSE, functionsBlackList = list('consecutiveCharactersText','punctuationRatio','upperCaseRatio','letterUpperCaseRatio') ),
  contextDatasets = list( 
    contexts$geospatial( # this context will train on geospatial contexts
      data = traindata, name = 'geo_context_data') ),
  revisionDescription = 'GeoContext', 
  run_blocking = FALSE
)



#adding open street map with world knowledge 
model_geo_control_geo_context = SparkBeyond::learn(
  projectName = "Airbnb_R_Primary",
  trainData = traindata,
  target = "PRICE",
  featureGeneration = featureGenerationControl(allowRangeFeatures = FALSE,numericEqualityFeatures = FALSE,equalityFeatures = FALSE, functionsBlackList = list('consecutiveCharactersText','punctuationRatio','upperCaseRatio','letterUpperCaseRatio') ),
  contextDatasets = list(
    contexts$geospatial( # this context will train on geospatial contexts
      data = traindata, name = 'geo_context_data') ),
  knowledge = knowledgeControl(openStreetMap = TRUE),
  revisionDescription = 'GeoContext_with_OSM', 
  run_blocking = FALSE
)


