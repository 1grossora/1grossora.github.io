from sparkbeyond._utils import validation
from datetime import datetime
import uuid

try:
    basestring
except NameError:
    basestring = str

class EnvironmentRepository:
    """Environment Management Repository.

    This module allows management of environments, environment types, and deploy groups.
    Most of the provided operations are simple CRUD actions.
    All of the actions are exposed through the :obj:`.environments.EnvironmentRepository` class which can be initiated
    via the :meth:`~.SdkSession.environments` method.

    Example:
        env_repo = client.environments()

        all_envs = env_repo.fetch_environments()
    """

    def __init__(self, user_session):
        self._user_session = user_session

    def fetch_environments(self):
        """ Fetch all of the existing environments from the server

        Returns:
            list of :obj:`.environments.Environment`: List of :obj:`.environments.Environment` objects,
                empty list in case there are no environments
        """
        return self._user_session.fetch_environments()

    def fetch_environment(self, environment_name):
        """ Fetch all of the existing environments from the server

        Args:
            environment_name (str): then name of the environment to fetch
        Returns:
            :obj:`.environments.Environment`: the requested :obj:`.environments.Environment`
        Raises:
            TypeError: in case environment_name is not of type str
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment_name, basestring, "Parameter environment_name must be of type str")
        return self._user_session.fetch_environment(environment_name)

    def add_environment(self, environment):
        """ Add a new environment to the server

        Args:
            environment (:obj:`.environments.Environment`): the environment to add
        Returns:
            :obj:`.environments.Environment`: the added :obj:`.environments.Environment`
        Raises:
            TypeError: in case environment is not of type :obj:`.environments.Environment`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment, Environment, "Parameter environment must be of type Environment")
        return self._user_session.add_environment(environment)

    def update_environment(self, environment):
        """ Update an environment

        Args:
            environment (:obj:`.environments.Environment`): the environment to update
        Returns:
            :obj:`.environments.Environment`: the updated :obj:`.environments.Environment`
        Raises:
            TypeError: in case environment is not of type :obj:`.environments.Environment`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment, Environment, "Parameter environment must be of type Environment")
        return self._user_session.update_environment(environment)

    def delete_environment(self, environment_name):
        """ Delete an environment

        Args:
            environment_name (str): the name of the environment to delete
        Raises:
            TypeError: in case environment_name is not of type ``str``
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment_name, basestring, "Parameter environment_name must be of type str")
        return self._user_session.delete_environment(environment_name)

    """Deployed Groups"""
    def get_deployed_groups(self):
        """ Get all of the existing deployed groups from the server

        Returns:
            list of :obj:`.environments.DeployGroup`: List of :obj:`.environments.DeployGroup` objects,
                empty list in case there are no deployed groups
        """
        return self._user_session.get_deployed_groups()

    def publish_deploy_group(self, deploy_group, force=False):
        """ Publish a deployed group
        The destination environmet must exists prior to creating the group

        Args:
            deploy_group (:obj:`.environments.DeployGroup`): the group to create
            force (bool): optional parameter, should override the currently publish model. default to False
        Returns:
            :obj:`.environments.DeployGroup`: the deployed group
        Raises:
            TypeError: in case deploy_group is not of type :obj:`.environments.DeployGroup`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(deploy_group, DeployGroup, "Parameter deploy_group must be of type DeployGroup")
        return self._user_session.publish_deploy_group(deploy_group, force)

    def remove_deploy_group(self, deploy_group):
        """ Delete (and undeploy) a deployed group

        Args:
            deploy_group (:obj:`.environments.DeployGroup`): the group to remove
        Raises:
            TypeError: in case deploy_group is not of type :obj:`.environments.DeployGroup`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(deploy_group, DeployGroup, "Parameter deploy_group must be of type DeployGroup")
        return self._user_session.remove_deploy_group(deploy_group)

    def get_environment_types(self):
        """ Get all of the existing environment types from the server

        Returns:
            list of :obj:`.environments.EnvironmentType`: List of :obj:`.environments.EnvironmentType` objects,
                                    empty list in case there are no environment types
        """
        return self._user_session.get_environment_types()

    def is_environment_type_exists(self, environment_type):
        """ Check if environment type exists in the server

        Args:
            environment_type (:obj:`.environments.EnvironmentType`): the :obj:`.environments.EnvironmentType` to check
        Returns:
            bool: True or False based on whether the :obj:`.environments.EnvironmentType` exists
        Raises:
            TypeError: in case environment_type is not of type :obj:`.environments.EnvironmentType`
        """
        validation.assert_type(environment_type,
                                EnvironmentType, "Parameter environment_type must be of type EnvironmentType")
        return self._user_session.is_environment_type_exists(environment_type)

    def add_environment_type(self, environment_type):
        """ Add environment type to the server

        Args:
            environment_type (:obj:`.environments.EnvironmentType`): the :obj:`.environments.EnvironmentType` to add
        Returns:
            :obj:`.environments.EnvironmentType`: the added :obj:`.environments.EnvironmentType`
        Raises:
            TypeError: in case environment_type is not of type :obj:`.environments.EnvironmentType`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment_type,
                                EnvironmentType, "Parameter environment_type must be of type EnvironmentType")
        return self._user_session.add_environment_type(environment_type)

    def delete_environment_type(self, environment_type):
        """ Delete environment type from the server

        Args:
            environment_type (:obj:`.environments.EnvironmentType`): the :obj:`.environments.EnvironmentType` to delete
        Raises:
            TypeError: in case environment_type is not of type :obj:`.environments.EnvironmentType`
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment_type,
                                EnvironmentType, "Parameter environment_type must be of type EnvironmentType")
        return self._user_session.delete_environment_type(environment_type)

    def get_environment_history(self, environment_name):
        """ Get the operations history of an  :obj:`.environments.Environment`

        Args:
            environment_name (str): The name of the environment
        Returns:
            list of :obj:`.environments.EnvironmentHistory`: the past statuses of an environment
        Raises:
            TypeError: in case environment_name is not of type str
            OperationFailure: in case the server returns error
        """
        validation.assert_type(environment_name, basestring, "Parameter environment_name must be of type str")
        return self._user_session.get_environment_history(environment_name)

    def get_all_environment_history(self):
        """ Get the entire operations history

        Returns:
            list of :obj:`.environments.EnvironmentHistory`: the past statuses of an environment
        Raises:
            OperationFailure: in case the server returns error
        """
        return self._user_session.get_all_environment_history()


class Environment:

    """ This class represents the Environment dto

    Args:
        name (str): The environment name
        display_name (str): The environment display name
        env_type (str): The environment type, should be identical to an existing
            name of :obj:`.environments.EnvironmentType`
        predbox_url (str): A url to a PredictionBox server
        predbox_token (str): An access token for the PredictionBox server
    """
    def __init__(
                self,
                name,
                display_name,
                env_type,
                predbox_url,
                predbox_token):
        self.name = name
        self.display_name = display_name
        self.env_type = env_type
        self.predbox_url = predbox_url
        self.predbox_token = predbox_token
        self.etag = str(uuid.uuid4())

    @classmethod
    def from_json(cls, json):
        env = Environment(
            name=json['name'],
            display_name=json['displayName'],
            env_type=json['envType'],
            predbox_url=json['predboxUrl'],
            predbox_token=json['predboxToken']
        )
        env.etag = json['etag']
        return env

    def __eq__(self, other):
        return (isinstance(other, Environment)
                and self.name == other.name
                and self.display_name == other.display_name
                and self.env_type == other.env_type
                and self.predbox_url == other.predbox_url
                and self.predbox_token == other.predbox_token
                and self.etag == other.etag)

    def __hash__(self):
        return hash((
            self.name,
            self.display_name,
            self.env_type,
            self.predbox_url,
            self.predbox_token,
            self.etag))


class DeployGroup:

    """ This class represents the DeployGroup dto

    Args:
        name (str): The deploy group name
        env_name (str): The environment name. should be identical to an existing name
            of :obj:`.environments.Environment`
        project_name (str): The name of the project to deploy.
        project_revision (int): The learn revision to deploy.
        created_by (str): The email address of the user that created the deploy group.
    """
    def __init__(
        self,
        env_name,
        project_name,
        project_revision,
        name="",
        created_by=""
    ):
        self.name = name
        self.env_name = env_name
        self.project_name = project_name
        self.project_revision = project_revision
        self.created_by = created_by
        self.etag = str(uuid.uuid4())

    @classmethod
    def from_json(cls, json):
        dg = DeployGroup(
            name=json['name'],
            env_name=json['envName'],
            project_name=json['projectName'],
            project_revision=json['projectRevision'],
            created_by=json['createdBy']
        )
        dg.etag = json['etag']
        return dg

    def __eq__(self, other):
        return (isinstance(other, DeployGroup)
                and self.env_name == other.env_name
                and self.project_name == other.project_name
                and self.project_revision == other.project_revision)

    def __hash__(self):
        return hash((
            self.env_name,
            self.project_name,
            self.project_revision))


class EnvironmentType:

    """ This class represents the EnvironmentType dto

    Args:
        name (str): The environment type name
    """
    def __init__(self, name):
        self.name = name
        self.etag = str(uuid.uuid4())

    @classmethod
    def from_json(cls, json):
        et = EnvironmentType(name=json['name'])
        et.etag = json['etag']
        return et

    def __eq__(self, other):
        return (isinstance(other, EnvironmentType)
                and self.name == other.name)

    def __hash__(self):
        return hash((
            self.name))


class EnvironmentHistory:

    """ This class represents a singe historical record of environment management

        Args:
        user (str): The user that performed the operation
        env_name (str): Environment name on which the operation was performed
        deployed_group (str): The deploy group on which the operation was performed
        status (str): A status
        created (datetime.datetime): Operation timestamp
        operation (str): The operation type
        project_name (str): The deployed project name
        project_revision (int): The deployed project revision
    """
    def __init__(self, user, env_name, deployed_group, operation, project_name, project_revision, status, created):
        self.user = user
        self.env_name = env_name
        self.deployed_group = deployed_group
        self.operation = operation
        self.project_name = project_name
        self.project_revision = project_revision
        self.status = status
        self.created = created

    @classmethod
    def from_json(cls, json):
        return EnvironmentHistory(
            user=json['user'],
            env_name=json['envName'],
            deployed_group=json['deployedGroup'],
            status=json['status'],
            created=datetime.fromtimestamp(json['created']/1000.0),
            operation=json['operation'],
            project_name=json['projectName'],
            project_revision=json['projectRevision'])

    def __eq__(self, other):
        return (isinstance(other, EnvironmentHistory)
                and self.user == other.user
                and self.env_name == other.env_name
                and self.deployed_group == other.deployed_group
                and self.status == other.status
                and self.created == other.created
                and self.operation == other.operation
                and self.project_name == other.project_name
                and self.project_revision == other.project_revision)

    def __hash__(self):
        return hash((
            self.user,
            self.env_name,
            self.deployed_group,
            self.status,
            self.created,
            self.operation,
            self.project_name,
            self.project_revision))
