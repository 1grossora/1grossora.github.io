import warnings
import collections


def _assert_type(obj, expected_type, message=None):
    if obj is not None and not isinstance(obj, expected_type):
        raise TypeError("{0} should be of type: {1}", obj, type if message is None else message)


class ResourceId:
    def __init__(self, remote_path):
        self.remote_path = remote_path


class FileReference:
    """ Represents a reference to a file on server

        Args:
            location (str): one of the base locations (Shared, Uploaded, Demo, Local, Project). Currently (1.16) only
                "Project" is used.
            path (str): relative (to "location", see above) path to a file
            project_name (str): required when using location="Project"
    """

    def __init__(self, location, path, project_name=None):
        self.location = location
        self.path = path
        self.projectName = project_name

    @classmethod
    def from_project_based_path(cls, project_name, path):
        return FileReference('Project', path, project_name)

    @classmethod
    def from_files_created_response_json(cls, json):
        # Response always contains only one file reference for SDK upload
        saved_input = json[0]['saved']
        return FileReference(saved_input['location'], saved_input['path'], saved_input['projectName'])


class ContextDatasetWrapper:
    """ A wrapper for context datasets """
    def __init__(self,
                 contextProvider=None,
                 name='context',
                 keyColumns=(),
                 timeColumn=None,
                 graphSourceNodeColumn=None,
                 graphTargetNodeColumn=None,
                 smoothingCoefficient=None,
                 asDiscrete=None,
                 maxRows=None,
                 maxCardinalityThreshold=None,
                 targetColumn=None,
                 contextTypes=None,
                 partitionBy=None,
                 maxPartitions=None):
        self.contextProvider = contextProvider
        self.name = name
        self.keyColumns = keyColumns
        self.timeColumn = timeColumn
        self.graphSourceNodeColumn = graphSourceNodeColumn
        self.graphTargetNodeColumn = graphTargetNodeColumn
        self.smoothingCoefficient = smoothingCoefficient
        self.asDiscrete = asDiscrete
        self.maxRows = maxRows
        self.maxCardinalityThreshold = maxCardinalityThreshold
        self.targetColumn = targetColumn
        self.contextTypes = contextTypes
        self.partitionBy = partitionBy
        self.maxPartitions = maxPartitions


class LearningParams:
    """ Learning Parameters """

    def __init__(self,
                 projectName,
                 trainingProvider,
                 target,
                 **kw):
        """
        Args:
            projectName: the name of the project (default None)
            trainingProvider: DataFrameInput like object representing data on server
            target: the column to be used as the predicted variable
        Keyword Args:
            revisionDescription: string revision comment
            testFilePath: relative (to project dir) file path to the test data file on server
            testProvider: DataFrameInput like object representing data on server
            trainTestSplitRatio: the fraction of the training data to be used for training. The remainedr is used for testing (default 0.8)
            contextDatasets: ???
            weightColumn: a column to be used as weights for each sample (default None)
            weightByClass: ??? (default False)
            timeWindowsDefinition: definition of time windows for timeseries contexts
            emptyValuePolicy: ???
            fileEncoding: the encoding of the input file (default ???)
            temporalSplitColumn: a column used for temporally splitting the data into training and testing sets (default None)
            fileEscaping: is the file using escaping (default True)
            linesForTypeDetection: the number of lines in the training set to be used for automatic column type detection (default 10000)
            localTopFeatureCount: the maximum number of features to be evalueated per column (default 1000)
            supportThreshold: the minumal number of samples needed to support a feature (deafult 3)
            maxDepth: the maximum feature search depth (default 2.5)
            expandedTimeSeries: A boolean indicator for whether to force at least 3.5 feature search depth if time series or keyed time series context is used (default True)
            featureSearchMode: ??? (defult 'DEFAULT')
            maxFeaturesCount: the maximum number of features to be used for model training (default 300)
            functionsWhiteList: a list of functions to be used exclusively for feature search (default None)
            functionsBlackList: a list of functions not to be used for feature search (default None)
            booleanNumericFeatures: express numeric features as boolean features using thresholds and ranges (default True)
            numericEqualityFeatures (bool): A boolean indicator for whether to include features that compare
                numeric fields with specific values. True by default.
            equalityFeatures (bool): A boolean indicator for whether to include features of the form form f(x) = y.
                True by default.
            allowRangeFeatures: ??? (default True)
            customColumnSubsets: list of lists of column subsets to be used with custom feature search parameters (default None)
            autoColumnSubSets: create custom column subsets automatically according to some criteria (default 'CONCEPT')
            useCachedFeatures: skip feature search if cached features exist (default True)
            maxFeatureDuration: the maximum number of milliseconds to be spent on a search of a single feature (default None)
            overrideMaxFeatureDurationForExternalData: ??? (default True)
            allocatedMemoryMB: ??? (default 3635)
            maxCollectionSize: ??? (default 200000)
            automaticSelectionOfNumberOfFeatures: try various numbers of features up to maxFeaturesCount (default False)
            regressionDiscretizerBinsOverride: a list of doubles to be used as bin edges for discretizing the target in the feature search step of regression problems (default None)
            regressionMode: ??? (default None)
            linkedDataCore: use the knowledge graph (default False)
            openStreetMap: use openStreetMap (default False)
            weather: use weather (default False)
            holidays: use public holidays database (default False)
            customFunctions: ??? (default None)
            algorithmsWhiteList: algorithms white list (default ['RRandomForestRegressor', 'RRandomForestClassifier'])
            evaluationMetric: model evaluation metric (default RMSE for regression, AUC for classification)
            crossValidation: number of cross validation folds (default 1)
            produceReports: ??? (default None)
            produceFeatureClusteringReport: produce feature clusters report (default False)
            scoreOnTestSet: produce a file with the prediction applied on the test data (default False)
            emailForNotification: email addres for notifications (default None)
            useRawNumericColumns: use the original numeric columns as features when building the model. This will automatically attempt to also build a model based only on the numeric columns with applying additional transformations on the data (default True)
            partitionColumn: A column name containing information by which the data will be split to tain/test/validation set. Allowed values: "Train", "Validation", "Test".
            gainThreshold (float): Remove features with information gain below the specified threshold.
            timeVSQualityFactor (float): For large datasets, consider decreasing if a long feature search runtime is expected.
            timeVSSmallSupportFactor (float): For large datasets, consider increasing if many small support features are expected (e.g. in some text processing problems). May slow down feature search.
            deduplicationSimilarityThreshold (float): Prune features by empirical similarity.
            acceleratedFeatureSearch (bool): Prune features by empirical similarity.
            learningMode (string): Select default settings consistent with a given learning strategy:
                Insight, OptimizeModel. Defaults to None.
                Insight Mode: Fast learning iterations with an emphasis on qualitative feature discovery.
                Features will convey insights into the problem while avoiding extended learning sessions intended to
                maximize predictive performance.
                OptimizeModel Mode: Predictive performance is paramount. This mode aims to provide a starting point for
                achieving strong predictive performance. The features may be less human friendly as they attempt to
                maximize signal extracted from the data. Runtime may be longer as larger and more models are built in
                the pursuit of performance.
            regressionNumberOfBins (int): Explicitly specify the number of bins for equal mass discretization of
                the continuous target (ignored when :attr:`regressionDiscretizerBinsOverride` is defined)
            parentRevision (int): parent revision for this learning. Set parent_revision = sparkbeyond.ProjectRevision.ROOT to put this revision under root. If no parent revision is specified, the server will find the most suitable.

        """
        self.projectName = projectName
        self.trainingProvider = trainingProvider
        self.target = target

        self.testFilePath = kw.get('testFilePath')
        self.testProvider = kw.get('testProvider')
        self.parentRevision = kw.get('parentRevision')

        self.revisionDescription = kw.get('revisionDescription')
        self.trainTestSplitRatio = kw.get('trainTestSplitRatio')
        self.contextDatasets = kw.get('contextDatasets')
        if self.contextDatasets is not None:
            _assert_type(self.contextDatasets, list, message = 'contextDatasets should be a list of ContextDatasetWrapper')
            for c in self.contextDatasets:
                _assert_type(c, ContextDatasetWrapper, 'contextDatasets should be a list of ContextDatasetWrapper')
        self.weightColumn = kw.get('weightColumn')
        self.weightByClass = kw.get('weightByClass')
        self.timeWindowsDefinition = kw.get('timeWindowsDefinition')

        self.emptyValuePolicy = kw.get('emptyValuePolicy')
        self.fileEncoding = kw.get('fileEncoding')
        self.temporalSplitColumn = kw.get('temporalSplitColumn')
        self.fileEscaping = kw.get('fileEscaping')
        self.linesForTypeDetection = kw.get('linesForTypeDetection')

        self.localTopFeatureCount = kw.get('localTopFeatureCount')
        self.supportThreshold = kw.get('supportThreshold')
        self.maxDepth = kw.get('maxDepth')
        self.expandedTimeSeries = kw.get('expandedTimeSeries')
        self.featureSearchMode = kw.get('featureSearchMode')
        self.maxFeaturesCount = kw.get('maxFeaturesCount')
        self.functionsWhiteList = kw.get('functionsWhiteList')
        self.functionsBlackList = kw.get('functionsBlackList')
        self.booleanNumericFeatures = kw.get('booleanNumericFeatures')
        self.numericEqualityFeatures = kw.get('numericEqualityFeatures')
        self.equalityFeatures = kw.get('equalityFeatures')
        self.allowRangeFeatures = kw.get('allowRangeFeatures')
        self.customColumnSubsets = kw.get('customColumnSubsets')
        self.autoColumnSubSets = kw.get('autoColumnSubSets')
        self.useCachedFeatures = kw.get('useCachedFeatures')
        self.maxFeatureDuration = kw.get('maxFeatureDuration')
        self.overrideMaxFeatureDurationForExternalData = kw.get('overrideMaxFeatureDurationForExternalData')
        self.allocatedMemoryMB = kw.get('allocatedMemoryMB')  # TODO: some more clever calculation
        self.maxCollectionSize = kw.get('maxCollectionSize')
        self.automaticSelectionOfNumberOfFeatures = kw.get('automaticSelectionOfNumberOfFeatures')
        self.regressionDiscretizerBinsOverride = kw.get('regressionDiscretizerBinsOverride')
        self.regressionNumberOfBins = kw.get('regressionNumberOfBins')
        self.regressionMode = kw.get('regressionMode')
        self.useRawNumericColumns = kw.get('useRawNumericColumns')

        # knowledge params
        # TODO: keep only linkedDataCore, openStreetMap, weather, holidays - retire all other knowledge flags in 1.17
        self.linkedDataCore = kw.get('linkedDataCore')
        self.openStreetMap = kw.get('openStreetMap')
        self.weather = kw.get('weather')
        self.holidays = kw.get('holidays')

        self.customFunctions = kw.get('customFunctions')

        self.algorithmsWhiteList = kw.get('algorithmsWhiteList')
        self.extraModels = kw.get('extraModels')
        self.evaluationMetric = kw.get('evaluationMetric')
        self.crossValidation = kw.get('crossValidation')
        self.validationSetRatio = kw.get('validationSetRatio')

        self.produceReports = kw.get('produceReports')
        self.produceFeatureClusteringReport = kw.get('produceFeatureClusteringReport')
        self.scoreOnTestSet = kw.get('scoreOnTestSet')
        self.emailForNotification = kw.get('emailForNotification')
        self.partitionColumn = kw.get('partitionColumn')

        self.gainThreshold = kw.get('gainThreshold')
        self.timeVSQualityFactor = kw.get('timeVSQualityFactor')
        self.timeVSSmallSupportFactor = kw.get('timeVSSmallSupportFactor')
        self.deduplicationSimilarityThreshold = kw.get('deduplicationSimilarityThreshold')
        self.acceleratedFeatureSearch = kw.get('acceleratedFeatureSearch')
        self.learningMode = kw.get('learningMode')


class LearningJob:
    def __init__(self, project_name, revision, job_id):
        self.project_name = project_name
        self.revision = revision
        self.job_id = job_id

    @classmethod
    def from_json(cls, json):
        artifact_path_tokens = json['artifactPath'].split('/')
        return LearningJob(project_name=artifact_path_tokens[-2],
                           revision=int(artifact_path_tokens[-1]),
                           job_id=json['jobId'])


class LearningJobStatus:

    class Statuses:
        QUEUED = "queued"
        RUNNING = "running"
        FAILED = "failed"
        CANCELED = "canceled"
        DONE = "done"
        TERMINATED = "terminated"

    def __init__(self, status, project_name, revision, job_id, error=None):
        self.status = status
        self.project_name = project_name
        self.revision = revision
        self.job_id = job_id
        self.error = error

    def has_finished(self):
        return self.status in (self.Statuses.CANCELED, self.Statuses.FAILED, self.Statuses.DONE)

    @classmethod
    def from_json(cls, json):
        job_status = str(json['status'])
        if job_status != LearningJobStatus.Statuses.FAILED:
            return LearningJobStatus(job_status, json['project'], json['revision'], json['id'])
        else:
            return LearningJobStatus(job_status, json['project'], json['revision'], json['id'],
                                     error=str(json['error']))


class Evaluation:
    """ Learning session evaluation results """

    def __init__(self, evaluation_method, score, summary, details):
        """
        Args:
            evaluation_method: one of the values from :obj:`.EvaluationMetric`
            score: evaluation score
            summary: String: short summary report
            details: dict: detailed evaluation info
        """

        self.evaluation_method = evaluation_method
        self.score = score
        self.summary = summary
        self.details = details

    @classmethod
    def from_json(cls, json):
        return Evaluation(evaluation_method=str(json['evaluationMethod']),
                          score=float(json['evaluation']['score']),
                          summary=str(json['evaluation']['summary']),
                          details=json['evaluation'])


class PredictParams:
    """ Parameters for prediction """

    def __init__(self,
                 projectName,
                 revision,
                 predictDataProvider,
                 includeOriginals,
                 includeEnriched,
                 includeExplanations,
                 columnWhiteList,
                 linesForContextMatchReport,
                 contexts,
                 includeTyperErrorReport):
        """
        Args:
            predictDataProvider: DataFrameInput like object representing data on server
        """
        self.projectName = projectName
        self.revision = revision
        self.input = predictDataProvider
        self.includeOriginals = includeOriginals
        self.includeEnriched = includeEnriched
        self.includeExplanations = includeExplanations
        self.columnsWhiteList = columnWhiteList
        self.contextDatasets = contexts
        self.linesForContextMatchReport = linesForContextMatchReport
        if self.contextDatasets is not None:
            _assert_type(self.contextDatasets, list, 'predictContexts should be a list of ContextDatasetWrapper')
            for c in self.contextDatasets:
                _assert_type(c, ContextDatasetWrapper, 'predictContexts should be a list of ContextDatasetWrapper')
        self.fileEscaping = False
        self.includeTyperErrorReport = includeTyperErrorReport


class EnrichParams:
    """ Parameters for enrichment """

    def __init__(self,
                 projectName,
                 revision,
                 enrichDataProvider,
                 featureCount,
                 includeOriginals,
                 columnsWhiteList,
                 linesForContextMatchReport,
                 contextDatasets,
                 includeTyperErrorReport):
        """
        Args:
            enrichDataProvider: DataFrameInput like object representing data on server
        """
        self.projectName = projectName
        self.revision = revision
        self.input = enrichDataProvider
        self.featureCount = featureCount
        self.includeOriginals = includeOriginals
        self.columnsWhiteList = columnsWhiteList
        self.linesForContextMatchReport = linesForContextMatchReport
        self.contextDatasets = contextDatasets
        if self.contextDatasets is not None:
            _assert_type(self.contextDatasets, list, 'contextDatasets should be a list of ContextDatasetWrapper')
            for c in self.contextDatasets:
                _assert_type(c, ContextDatasetWrapper, 'contextDatasets should be a list of ContextDatasetWrapper')
        self.fileEscaping = False
        self.includeTyperErrorReport = includeTyperErrorReport


class EnrichPredictJobStatus:
    """ Status of the enrichment/prediction job """
    def __init__(self, built_contexts, processed_rows, typer_errors_report):
        self.built_contexts = built_contexts
        self.processed_rows = processed_rows
        self.typer_errors_report = typer_errors_report

    @classmethod
    def from_json(cls, json):
        return EnrichPredictJobStatus(
            json['builtContexts'] if json.get('builtContexts') is not None else False,
            json['processedRows']['amount'] if json.get('processedRows') is not None else 0,
            json.get('typerErrorsReport') if json.get('typerErrorsReport') is not None else []
        )


class JobResult:
    def __init__(self, error, success):
        if (error is not None and success is not None) or (error is None and success is None):
            raise ValueError('Exactly one of the fields should be defined - either success or failure')
        self.error = error,
        self.success = success

    def is_succeeded(self):
        return self.success is not None

    @classmethod
    def from_json(cls, json):
        return JobResult(json.get('failure'), json.get('success'))


class JobState:
    """Job state.

        Args:
            job_id (str): job id.
            enqueued_millis (long): when the job was successfully scheduled.
            started_millis (long): when the job execution started.
            ended_millis (long): when the job execution finished.
            worker_id (str): logical id of the worker on which the job was executed.
    """

    def __init__(self, job_id, enqueued_millis, started_millis, ended_millis, worker_id):
        self.job_id = job_id
        self.enqueued_millis = enqueued_millis
        self.started_millis = started_millis
        self.ended_millis = ended_millis
        self.worker_id = worker_id

    def is_enqueued(self):
        return self.enqueued_millis is not None and self.started_millis is None

    def is_running(self):
        return self.started_millis is not None and self.ended_millis is None

    def is_completed(self):
        return self.ended_millis is not None


class EnrichPredictJobState(JobState):
    """State of enrich or predict job.

        Args:
            job_id (str): job id.
            enqueued_millis (long): when the job was successfully scheduled.
            started_millis (long): when the job execution started.
            ended_millis (long): when the job execution finished.
            worker_id (str): logical id of the worker on which the job was executed.
            status (EnrichPredictJobStatus): detailed progress information when the job is executed.
            result (JobResult): job result.
    """

    def __init__(self, job_id, enqueued_millis, started_millis, ended_millis, worker_id, status, result):
        JobState.__init__(self, job_id, enqueued_millis, started_millis, ended_millis, worker_id)
        self.status=status
        self.result=result

    @classmethod
    def from_json(cls, json):
        return EnrichPredictJobState(
            job_id=json['id'],
            enqueued_millis=json['enqueued']/1000 if json.get('enqueued') is not None else None,
            started_millis=json['started']/1000 if json.get('started') is not None else None,
            ended_millis=json['ended']/1000 if json.get('ended') is not None else None,
            worker_id=json['worker']['logicalId'] if json.get('worker') is not None else None,
            status=EnrichPredictJobStatus.from_json(json['status']) if json.get('status') is not None else None,
            result=JobResult.from_json(json['result']) if json.get('result') is not None else None
        )


class PredictionReportsJobState(JobState):
    """State of prediction reports job.

        Args:
            job_id (str): job id.
            enqueued_millis (long): when the job was successfully scheduled.
            started_millis (long): when the job execution started.
            ended_millis (long): when the job execution finished.
            worker_id (str): logical id of the worker on which the job was executed.
            result (JobResult): job result.
    """

    def __init__(self, job_id, enqueued_millis, started_millis, ended_millis, worker_id, result):
        JobState.__init__(self, job_id, enqueued_millis, started_millis, ended_millis, worker_id)
        self.result = result

    @classmethod
    def from_json(cls, json):
        return PredictionReportsJobState(
            job_id=json['id'],
            enqueued_millis=json['enqueued'] / 1000 if json.get('enqueued') is not None else None,
            started_millis=json['started'] / 1000 if json.get('started') is not None else None,
            ended_millis=json['ended'] / 1000 if json.get('ended') is not None else None,
            worker_id=json['worker']['logicalId'] if json.get('worker') is not None else None,
            result=JobResult.from_json(json['result']) if json.get('result') is not None else None
        )


class BuildInfo:
    """Server build information"""
    def __init__(self, release_number, git_revision):
        self.release_number = release_number
        self.git_revision = git_revision


# DataFrameInput
FileDataSet = collections.namedtuple('FileDataSet', ['location', 'encoding', 'isQuoted', 'useEscaping'])
LocalFile = collections.namedtuple('LocalFile', ['source', 'name', 'emptyValuePolicy', 'jsonClass'])

OpenStreetMapFile = collections.namedtuple('OpenStreetMapFile', ['location', 'name', 'jsonClass'])

ShapeFile = collections.namedtuple('ShapeFile', ['location', 'name', 'jsonClass'])

FeaturesFromRevision = collections.namedtuple('FeaturesFromRevision', ['revisionId', 'name', 'jsonClass'])

Word2Vec = collections.namedtuple('Word2Vec', ['source', 'name', 'jsonClass'])

UrlFileDataSet = collections.namedtuple('UrlFileDataSet', ['url', 'jsonClass'])
WebFile = collections.namedtuple('WebFile', ['source', 'name', 'jsonClass'])


class DataFrameInputs:
    @staticmethod
    def local_file(name, file_reference, encoding=None, is_quoted=None, use_escaping=None, empty_value_policy=None):
        return LocalFile(source=FileDataSet(file_reference, encoding, is_quoted, use_escaping),
                         name=name,
                         emptyValuePolicy=empty_value_policy,
                         jsonClass='com.sparkbeyond.runtime.data.transform.LocalFile')

    @staticmethod
    def osm_file(name, file_reference):
        return OpenStreetMapFile(location=file_reference,
                                 name=name,
                                 jsonClass="com.sparkbeyond.runtime.data.transform.OpenStreetMapFileInput")

    @staticmethod
    def shape_file(name, file_reference):
        return ShapeFile(location=file_reference,
                         name=name,
                         jsonClass="com.sparkbeyond.runtime.data.transform.ShapeFileInput")

    @staticmethod
    def features_from_revision(name, revision):
        return FeaturesFromRevision(revisionId=revision,
                                    name=name,
                                    jsonClass="com.sparkbeyond.runtime.data.transform.FeaturesFromRevision")

    @staticmethod
    def word_2_vec(name, source):
        return Word2Vec(source=source,
                        name=name,
                        jsonClass="com.sparkbeyond.runtime.data.transform.Word2Vec")

    @staticmethod
    def web_file(name, url):
        return WebFile(source=UrlFileDataSet(url=url, jsonClass="com.sparkbeyond.runtime.data.source.UrlFileDataSet"),
                       name=name,
                       jsonClass="com.sparkbeyond.runtime.data.transform.WebFile")


class OperationFailure(Exception):
    pass


# World knowledge
class WorldKnowledgeContextType(object):
    LOOKUP = "Lookup"
    TIME_SERIES = "TimeSeries"

    _context_types = {'lookup': LOOKUP,
                      'timeSeries': TIME_SERIES}

    @staticmethod
    def from_str(context_type):
        return WorldKnowledgeContextType._context_types[context_type]


class WorldKnowledgeContextColumn(collections.namedtuple('WorldKnowledgeContextColumn',
                                                         ['name', 'type'])):
    @classmethod
    def from_json(cls, json):
        return WorldKnowledgeContextColumn(json['name'], json['columnType'])


class WorldKnowledgeContextMetadata(collections.namedtuple('WorldKnowledgeContextMetadata',
                                                           ['key_columns', 'time_column', 'context_type'])):
    @classmethod
    def from_json(cls, json):
        time_column = WorldKnowledgeContextColumn.from_json(json.get('timeColumn')) \
            if json.get('timeColumn') is not None else None
        key_columns = [WorldKnowledgeContextColumn.from_json(col) for col in json['keyColumns']]
        return WorldKnowledgeContextMetadata(key_columns, time_column,
                                             WorldKnowledgeContextType.from_str(json['contextType']))


class WorldKnowledgeDatasetMetadata(collections.namedtuple('WorldKnowledgeDatasetMetadata',
                                                           ['name', 'display_name',
                                                            'category', 'description',
                                                            'context', 'rows', 'columns', 'size_bytes',
                                                            'uploaded_by', 'updated_on',
                                                            'url'])):
    @classmethod
    def from_json(cls, json):
        return WorldKnowledgeDatasetMetadata(json['name'], json['displayName'],
                                             json['category'], json['description'],
                                             WorldKnowledgeContextMetadata.from_json(json['context']),
                                             json['rows'], json['columns'], json['sizeBytes'],
                                             json['uploadedBy'], json['updatedOn'],
                                             json['url'])


class WorldKnowledgeResponse:
    def __init__(self, objects_metadata, sync_failure):
        self.objects_metadata = objects_metadata
        self.sync_failure = sync_failure

    @classmethod
    def from_json(cls, json):
        objects_metadata = [WorldKnowledgeDatasetMetadata.from_json(i) for i in json['objectsMetadata']]
        sync_failure = json.get('syncFailure')

        return WorldKnowledgeResponse(objects_metadata, sync_failure)
