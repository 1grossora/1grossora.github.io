import sparkbeyond


class Version:
    def __init__(self, version_string):
        self.version_string = version_string
        version_tuple = tuple(map(int, (version_string.split("."))))
        if len(version_tuple) == 2:
            version_tuple = version_tuple + (0,)
        elif len(version_tuple) == 1:
            version_tuple = version_tuple + (0, 0,)
        else:
            version_tuple = version_tuple
        (self.major, self.minor, self.patch) = version_tuple

    def compare(self, version):
        if self.major > version.major:
            return 1
        elif self.major < version.major:
            return -1
        elif self.minor > version.minor:
            return 1
        elif self.minor < version.minor:
            return -1
        elif self.patch > version.patch:
            return 1
        elif self.patch < version.patch:
            return -1
        else:
            return 0

    def compare_minor(self, version):
        if self.major > version.major:
            return 1
        elif self.major < version.major:
            return -1
        elif self.minor > version.minor:
            return 1
        elif self.minor < version.minor:
            return -1
        else:
            return 0

    def __str__(self):
        return self.version_string


def _is_version_compatible(client_ver, server_ver):
    # type: (Version, Version) -> bool
    return client_ver.major == server_ver.major and \
            (client_ver.minor == server_ver.minor or client_ver.minor - 1 == server_ver.minor)


def validate_server_compatibility(server_version):
    # type: (Version, Version) -> None
    client_version = Version(sparkbeyond.__version__)
    if not _is_version_compatible(client_version, server_version):
        raise Exception("Incompatible server version found: {0}, while using client version: {1}"
                        .format(server_version, client_version))


class CompatibilityHelper:
    def __init__(self, server_version):
        self.server_version = server_version

    def is_server_version_older_than(self, version):
        # type: (Version) -> bool
        return self.server_version.compare(version) < 0

    def assert_minimum_server_version(self, version, feature_name='Feature'):
        # type: (Version, str) -> None
        """Raise exception if server version is older than required
            Args:
                version (str): minimum required version
                feature_name (str): Name of the feature related to the requirement. Used for error message formatting.
        """
        if self.is_server_version_older_than(version):
            raise Exception(
                "{0} implementation is incompatible with server version {1}, requires minimum server version {2}"
                    .format(feature_name, self.server_version, version))
