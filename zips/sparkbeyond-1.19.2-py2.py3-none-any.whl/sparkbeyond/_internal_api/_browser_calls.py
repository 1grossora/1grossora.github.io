import webbrowser
from requests.compat import urljoin


def _full_url(base_url, relative_url_path):
    return urljoin(base_url, relative_url_path)


def revision_web_link(token, base_url, project_name, revision):
    """Start a browser page with a web view of the project"""
    return _full_url(
        base_url,
        "/?token={0}#/visualPipeline/{1}/{2}".format(token, project_name, revision)
    )


def browse_revision(token, base_url, project_name, revision):
    """Start a browser page with a web view of the project"""
    webbrowser.open(revision_web_link(token, base_url, project_name, revision))


def browse_prediction_report(token, base_url, reports_job_id, filename):
    """Open the specified report in a web browser"""
    browse_path = "/api/predictionReportFile/{0}/{1}?token={2}".format(reports_job_id, filename, token)
    webbrowser.open(_full_url(base_url, browse_path))
