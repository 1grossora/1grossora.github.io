import logging

from requests.packages.urllib3.exceptions import InsecureRequestWarning
import requests
from requests.compat import urljoin

from .api_dtos import *
from . import _api_calls
from . import _browser_calls
from sparkbeyond._internal_api._compatibility import Version, CompatibilityHelper, validate_server_compatibility
import sparkbeyond

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

log = logging.getLogger(__name__)


class UserSession:
    def __init__(self, url, username, password, verify_ssl_certificate=True):
        self._session = requests.Session()
        self._base_url = url
        self._session.verify = verify_ssl_certificate
        login_url = urljoin(self._base_url, '/login')
        self._session.headers.update({'X-Requested-With': 'XMLHttpRequest', 'X-SparkBeyond-Client': 'Python SDK {}'.format(sparkbeyond.__version__)})
        if username is None or password is None:
            raise ValueError("Username or password undefined")
        response = self._session.post(login_url,
                                      data={'email': username, 'password': password})
        if response.status_code >= 400:
            raise Exception('Login failed: {}'.format(response.text))
        if 'Set-Cookie' not in response.headers:
            raise Exception('Authentication failed')

        build_info = self.get_build_info()
        self.server_version = Version(build_info.release_number)
        validate_server_compatibility(self.server_version)
        log.info("Server version: %s", self.server_version)
        self._compatibility_helper = CompatibilityHelper(self.server_version)

    def is_server_version_older_than(self, version):
        """ Check if server version is too old

            Args:
                version (string): version string
            Returns:
                bool: True if the version is older than the server version, and False otherwise
        """
        return self._compatibility_helper.is_server_version_older_than(Version(version))

    """*** API methods ***"""
    def file_exists(self, project_name, path):
        """ Returns FileReference object representing the file on server, if exists, None otherwise
        Args:
            project_name: the project's name
            path: the path

        Returns:
            FileReference object, representing the uploaded file on the server, if exists,
                None if the file doesn't exist
        """
        file_reference = FileReference.from_project_based_path(project_name, path)
        return file_reference if _api_calls.file_exists(self._session, self._base_url, file_reference) else None


    def upload_file(self, project_name, local_path):
        """
        Upload a file to the server, create a project if it doesn't exist

        Args:
            project_name: the project's name
            path: the path

        Returns:
            FileReference  object, representing the uploaded file on the server
            
        Raises:
            Exception: If the file upload fails
        """
        return _api_calls.upload_file(self._session, self._base_url, project_name, local_path)

    def download_file(self, project_name, revision, resource_id, local_path):
        return _api_calls.download_file(self._session, self._base_url, project_name, revision, resource_id, local_path)

    def create_learning_job(self, learning_params):
        """
        Start a learning job
        Args:
            learning_params:
        Returns:
            LearningJob object, representing learning job execution
        """
        return _api_calls.create_learning_job(self._session, self._base_url,learning_params)

    def create_learning_job_based_on_existing_pipeline(self, project_name, inputs, revision=None):
        return _api_calls.create_learning_job_based_on_existing_pipeline(self._session, self._base_url,
                                                                         project_name, inputs, revision)

    def get_learning_job_status(self, job_id):
        return _api_calls.get_learning_job_status(self._session, self._base_url, job_id)

    def show_jobs(self, project_name=None, status=None):
        return _api_calls.show_jobs(self._session, self._base_url, project_name, status)

    def get_model_evaluation(self, project_name, revision):
        return _api_calls.get_model_evaluation(self._session, self._base_url, project_name, revision)

    def download_feature_extractor(self, project_name, revision):
        extcode_file = "extcode.ser"
        if self.is_server_version_older_than("1.17"):
            extcode_file = "extcode.dat"

        return _api_calls.download(self._session, self._base_url,
                                   rel_url="/analytics/rawFile/{0}/{1}/{2}".format(project_name,
                                                                                   revision,
                                                                                   extcode_file),
                                   local_path=extcode_file)

    def download_model(self, project_name, revision):
        return _api_calls.download(self._session, self._base_url,
                                   rel_url="/analytics/rawFile/{0}/{1}/model.ser".format(project_name, revision),
                                   local_path="model.ser")

    def download_contexts(self, project_name, revision, local_path=None):
        return _api_calls.download(self._session, self._base_url,
                                   rel_url="/api2/downloadContexts/{0}/{1}".format(project_name, revision),
                                   local_path=local_path)

    def export_model_to_prediction_box(self, project_name, revision,
                                       prediction_box_url, auth_key=None,
                                       upload_extractor=None, upload_model=None, upload_contexts=None,
                                       overwrite_existing=None, override_target_group_name=None):
        return _api_calls.export_model_to_prediction_box(
            self._session, self._base_url,
            project_name=project_name, revision=revision,
            prediction_box_url=prediction_box_url, auth_key=auth_key,
            upload_extractor=upload_extractor, upload_model=upload_model, upload_contexts=upload_contexts,
            overwrite_existing=overwrite_existing, override_target_group_name=override_target_group_name)

    def get_generated_features(self, project_name, revision):
        return _api_calls.get_generated_features(self._session, self._base_url, project_name, revision)

    def learn_streaming_api(self, project_name, revision, prev_line):
        return _api_calls.learn_streaming_api(self._session, self._base_url, project_name, revision, prev_line)

    def _get_token(self):
        return _api_calls.get_token(self._session, self._base_url)

    def predict(self, predict_params):
        return _api_calls.predict(self._session, self._base_url, predict_params)

    def enrich(self, enrich_params):
        return _api_calls.enrich(self._session, self._base_url, enrich_params)

    def get_predict_evaluation(self, reports_job_id):
        return _api_calls.get_predict_evaluation(self._session, self._base_url, reports_job_id)

    def get_enrich_predict_job_state(self, job_id):
        return _api_calls.get_enrich_predict_job_state(self._session, self._base_url, job_id)

    def download_job_result(self, job_id, local_path):
        return _api_calls.download(self._session, self._base_url,
                                   rel_url="/api/downloadJobResult/{0}".format(job_id),
                                   local_path=local_path)

    def cancel_job(self, job_id):
        return _api_calls.cancel_job(self._session, self._base_url, job_id)

    def get_prediction_reports_job_state(self, job_id):
        return _api_calls.get_prediction_reports_job_state(self._session, self._base_url, job_id)

    def generate_prediction_reports(self, predict_job_id, percent_of_population_to_plot):
        return _api_calls.generate_prediction_reports(self._session, self._base_url,
                                                      predict_job_id, percent_of_population_to_plot)

    def show_prediction_report(self, reports_job_id, filename):
        token = self._get_token()
        _browser_calls.browse_prediction_report(token, self._base_url, reports_job_id, filename)

    def get_typer_errors_report_from_json(self, job_id):
        return _api_calls.get_typer_errors_report_from_json(self._session, self._base_url, job_id)

    def get_supported_algorithms(self):
        return _api_calls.get_supported_algorithms(self._session, self._base_url)

    def get_build_info(self):
        return _api_calls.get_build_info(self._session, self._base_url)

    def get_inputs_structure(self, project_name, revision):
        return _api_calls.get_inputs_structure(self._session, self._base_url, project_name, revision)

    def get_inputs_schema(self, project_name, revision):
        return _api_calls.get_inputs_schema(self._session, self._base_url, project_name, revision)

    def check_types(self, project_name, revision, input_name, input_provider, typers,
                    take_rows, examples_per_column):
        return _api_calls.check_types(self._session, self._base_url, project_name, revision, input_name,
                                      input_provider, typers, take_rows, examples_per_column)

    """*** Browser methods ***"""
    def browse_revision(self, project_name, revision):
        """ start a browser page with a web view of the project """
        token = self._get_token()
        _browser_calls.browse_revision(token, self._base_url, project_name, revision)

    def revision_web_link(self, project_name, revision):
        """ Get the link to revision's web view """
        token = self._get_token()
        return _browser_calls.revision_web_link(token, self._base_url, project_name, revision)

    def fetch_environments(self):
        return _api_calls.fetch_environments(self._session, self._base_url)

    def fetch_environment(self, environment_name):
        return _api_calls.fetch_environment(self._session, self._base_url, environment_name)

    def add_environment(self, environment):
        return _api_calls.add_environment(self._session, self._base_url, environment)

    def delete_environment(self, environment_name):
        resp = _api_calls.delete_environment(self._session, self._base_url, environment_name)
        return resp

    def update_environment(self, environment):
        return _api_calls.update_environment(self._session, self._base_url, environment)

    def get_environment_types(self):
        return _api_calls.get_environment_types(self._session, self._base_url)

    def is_environment_type_exists(self, environment_type):
        return _api_calls.is_environment_type_exists(self._session, self._base_url, environment_type)

    def add_environment_type(self, environment_type):
        return _api_calls.add_environment_type(self._session, self._base_url, environment_type)

    def delete_environment_type(self, environment_type):
        return _api_calls.delete_environment_type(self._session, self._base_url, environment_type)

    def get_deployed_groups(self):
        return _api_calls.get_deployed_groups(self._session, self._base_url)

    def publish_deploy_group(self, deploy_group, force):
        return _api_calls.publish_deploy_group(self._session, self._base_url, deploy_group, force)

    def remove_deploy_group(self, deploy_group):
        return _api_calls.remove_deploy_group(self._session, self._base_url, deploy_group)

    def get_environment_history(self, environment_name):
        return _api_calls.get_environment_history(self._session, self._base_url, environment_name)

    def get_all_environment_history(self):
        return _api_calls.get_all_environment_history(self._session, self._base_url)

    # World knowledge
    def get_world_knowledge_objects_metadata(self):
        return _api_calls.get_world_knowledge_objects_metadata(self._session, self._base_url)

    def download_world_knowledge_object_data(self, dataset_name):
        return _api_calls.download(self._session, self._base_url,
                                   rel_url="/api/v1/worldKnowledgeObjects/{}/download".format(dataset_name))
