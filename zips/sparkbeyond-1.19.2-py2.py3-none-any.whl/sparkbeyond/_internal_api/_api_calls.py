from functools import wraps

from .api_dtos import *
from pandas import read_csv
import os
import sys
import json
import cgi
from tqdm import tqdm
import requests
from requests.compat import urljoin
import logging
from sparkbeyond._utils import validation
from sparkbeyond.environments import *
import re
import urllib

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO

"""API Calls

This module contains wrappers around api calls.
The module is stateless, its functions receive `requests.Session` object as an argument an use it to execute the request
"""

log = logging.getLogger(__name__)


class SimpleJsonEncoder(json.JSONEncoder):
    def default(self, obj):
        return obj.__dict__


under_pat = re.compile(r'_([a-z])')


def underscore_to_camel(name):
    return under_pat.sub(lambda x: x.group(1).upper(), name)


def convert_json(obj, convert):
    return {convert(key): (convert_json(val, convert) if isinstance(val, dict) else val) for key, val in obj.items()}


class JsonCamelcaseEncoder(json.JSONEncoder):
    def default(self, obj):
        return obj.__dict__

    def encode(self, obj):
        return json.JSONEncoder.encode(self, convert_json(obj, underscore_to_camel))


def _deserialize_json_from_response(response, deserializer=None):
    if not response.text:
        return None
    structured_json = json.loads(response.text)
    if deserializer is not None:
        return deserializer(structured_json)
    else:
        return structured_json


def _deserialize_json_result(deserializer=None):
    def decorate(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            response = func(*args, **kwargs)
            return _deserialize_json_from_response(response, deserializer)

        return wrapper

    return decorate


def _deserialize_text_result(transformation=None):
    def decorate(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            response = func(*args, **kwargs)
            if not response.text:
                return None
            response = response.text
            if transformation is not None:
                response = transformation(response)
            return response

        return wrapper

    return decorate


def _http_error_handling(retries=1):
    def extract_error_from_response(response):
        try:
            response_body = json.loads(response.text)
            return response_body['error']
        except Exception as e:
            return None

    def decorate(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            retries_num = retries
            attempt_number = 1

            while attempt_number <= retries_num:
                try:
                    response = func(*args, **kwargs)
                    response.raise_for_status()

                    operational_error = extract_error_from_response(response)
                    if operational_error is None:
                        return response
                    else:
                        raise OperationFailure(operational_error)

                except requests.exceptions.HTTPError as e:
                    if attempt_number >= retries_num:
                        content_type = e.response.headers.get('content-type')
                        if content_type is not None and 'text/plain' in content_type:
                            content = "Status code: {0}, Message: {1}".format(e.response.status_code, e.response.content)
                            raise OperationFailure(content)
                        elif content_type is not None and 'application/json' in content_type:
                            message = e.response.text
                            res_json = json.loads(message)

                            if 'message' in res_json:
                                message = res_json['message']

                            content = "Status code: {0}, Message: {1}".format(e.response.status_code,
                                                                              message)
                            raise OperationFailure(content)
                        raise e
                    else:
                        attempt_number += 1
                except requests.exceptions.RequestException as e:
                    if attempt_number >= retries_num:
                        raise e
                    else:
                        attempt_number += 1
        return wrapper

    return decorate


def _error_handling(retries=1):
    def decorate(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            retries_num = retries
            attempt_number = 1

            while attempt_number <= retries_num:
                try:
                    result = func(*args, **kwargs)
                    return result
                except requests.exceptions.RequestException as e:
                    if attempt_number >= retries_num:
                        log.error(e)
                        raise e
                    else:
                        attempt_number += 1
        return wrapper

    return decorate


def _full_url(base_url, relative_url_path):
    return urljoin(base_url, relative_url_path)


def _dict_to_json_filter_none_values(d):
    filtered = dict((a, b) for (a, b) in d.items() if b is not None)
    return json.dumps(filtered, cls=SimpleJsonEncoder)


def _to_json_filter_none_values(obj):
    if isinstance(obj, list):
        return [_to_json_filter_none_values(element) for element in obj]
    elif isinstance(obj, dict):
        return {key: _to_json_filter_none_values(val) for key, val in obj.items() if val is not None}
    elif hasattr(obj, '__dict__'):
        return {key: _to_json_filter_none_values(val) for key, val in obj.__dict__.items() if val is not None}
    elif hasattr(obj, '_asdict'):
        return {key: _to_json_filter_none_values(val) for key, val in obj._asdict().items() if val is not None}
    else:
        return obj


def _to_json_filter_none_values_camel_case(obj):
    return json.dumps(_to_json_filter_none_values(obj), cls=JsonCamelcaseEncoder)


def _to_json_filter_none_values_simple_encoder(obj):
    return json.dumps(_to_json_filter_none_values(obj), cls=SimpleJsonEncoder)


def file_exists(session, base_url, file_reference):
    """ Returns True if the file represented by file_reference exists"""
    url = _full_url(base_url, '/api/v1/files/{}/{}{}'.format(file_reference.location, file_reference.path,
                                                             '' if file_reference.projectName is None else
                                                             '?project={}'.format(file_reference.projectName)))
    resp = session.head(url)
    return resp.status_code == 200


# todo: should get file_reference s a parameted, to allow uploading to shared locations
# Leaving it with the old arguments (in 1.16) to minimize the backward compatibility related changes
@_error_handling(retries=3)
def upload_file(session, base_url, project_name, local_path):
    """Upload a file from local path to the relevant project's folder on server"""

    def read_in_chunks(file_path, chunk_size=65536):
        """Lazy function (generator) to read a file piece by piece.
        Default chunk size: 64k."""
        file_size = os.path.getsize(file_path)
        file_name = os.path.basename(file_path)
        log.info('Uploading %s', file_name)
        with tqdm(total=file_size, unit='B', unit_scale=True, file=sys.stdout) as progress_bar:
            with open(file_path, 'rb') as f:
                total_processed = 0
                while True:
                    data = f.read(chunk_size)
                    total_processed += chunk_size
                    if data:
                        if total_processed > file_size:
                            chunk_size -= total_processed - file_size
                        progress_bar.update(chunk_size)
                        yield data
                    else:
                        break

    def execute_request(url):
        resp = session.put(url, data=read_in_chunks(local_path))
        if resp.status_code == 200:
            return _deserialize_json_from_response(resp, deserializer=FileReference.from_files_created_response_json)
        elif resp.status_code == 409:
            return FileReference.from_project_based_path(project_name, basename)
        else:
            resp.raise_for_status()

    basename = os.path.basename(local_path)
    upload_url = _full_url(base_url, '/api/v1/files/Project/{}?project={}&createProjectIfAbsent=true'
                           .format(basename, project_name))

    return execute_request(upload_url)


@_error_handling(retries=3)
def download(session, base_url, rel_url, local_path=None):
    def extract_filename_from_content_disposition(response):
        content_disposition_header = response.headers.get("Content-disposition")
        if content_disposition_header is not None:
            value, params = cgi.parse_header(content_disposition_header)
            return params['filename'] if params is not None else None
        return None

    response = session.get(_full_url(base_url, rel_url), stream=True)
    response.raise_for_status()
    file_name = extract_filename_from_content_disposition(response)
    local_path = local_path or file_name or "downloaded.tmp"
    download_size = int(response.headers['Content-Length']) if 'Content-Length' in response.headers else None

    log.debug("Starting to download from %s to %s. Size: %s", rel_url, local_path, download_size)

    with open(local_path, 'wb') as f:
        iter_with_progress = tqdm(response.iter_content(chunk_size=4096),
                                  total=download_size/4096+1 if download_size is not None else None,
                                  unit='B', unit_scale=True, file=sys.stdout)
        for data in iter_with_progress:
            f.write(data)

    return os.path.abspath(local_path)


def download_file(session, base_url, project_name, revision, resource_id, local_path):
    """Download a file from relative path revisions folder"""
    validation.assert_type(resource_id, ResourceId)
    url = '/api2/downloadFile/%s/%d/%s' % (project_name, revision, resource_id.remote_path)
    resp = session.get(_full_url(base_url, url))
    if resp.status_code == 200:
        open(local_path, 'wb').write(resp.content)
    log.debug(("Downloaded file saved at: %s" % os.path.abspath(local_path)))
    return local_path

@_deserialize_json_result(LearningJob.from_json)
@_http_error_handling()
def create_learning_job(session, base_url, learning_params):
    """Start a learning job"""
    validation.assert_type(learning_params, LearningParams)

    return session.post(url=_full_url(base_url, '/api/learn'),
                        data=_to_json_filter_none_values_camel_case(learning_params),
                        headers={'content-type': 'application/json'})


def create_learning_job_based_on_existing_pipeline(session, base_url, project_name, inputs, revision = None):
    @_deserialize_json_result()
    @_http_error_handling()
    def execute_request():
        response = session.post(url=_full_url(base_url, '/api/runPipeline'),
                            data=_to_json_filter_none_values_simple_encoder(
                                {'project': project_name,
                                 'inputs': inputs,
                                 'revision': revision}),
                            headers={'content-type': 'application/json'}
                            )
        return response

    response_body = execute_request()
    return LearningJob(project_name=project_name,
                       revision=response_body['revision'],
                       job_id=response_body['jobId'])


@_deserialize_json_result(LearningJobStatus.from_json)
@_http_error_handling()
def get_learning_job_status(session, base_url, job_id):
    """Get learning job status"""
    resp = session.get(_full_url(base_url, "/api2/jobs/{0}".format(job_id)))
    return resp


@_deserialize_json_result(lambda json: [LearningJobStatus.from_json(i) for i in json])
@_http_error_handling()
def show_jobs(session, base_url, project_name, status):
    try:
        import urlparse
        from urllib import urlencode
    except:  # For Python 3
        import urllib.parse as urlparse
        from urllib.parse import urlencode

    params = {k: v for k, v in {'project_name': project_name, 'status': status}.items() if v is not None}
    return session.get(_full_url(base_url, "/api2/jobs?{}".format(urlencode(params))))


@_deserialize_json_result(Evaluation.from_json)
@_http_error_handling()
def get_model_evaluation(session, base_url, project_name, revision):
    url = '/api/notificationsLog/%s/%s?path=/json/evaluation.json' % (project_name, revision)
    resp = session.get(_full_url(base_url, url))
    return resp


def get_generated_features(session, base_url, project_name, revision):
    """ Return a pandas data frame with the found features """
    url = '/api/notificationsLog/%s/%s?path=/reports/features/train_features.tsv' % (project_name, revision)
    resp = session.get(_full_url(base_url, url))
    if resp.status_code == 200:
        return read_csv(StringIO(resp.text), sep='\t')
    else:
        return None


def learn_streaming_api(session, base_url, project_name, revision, prev_line):
    @_http_error_handling()
    def execute_streaming_call():
        url = '/api/notificationsLog/{0}/{1}?path=UInotification.log&skipLines={2}'.format(project_name,revision,prev_line)
        return session.get(_full_url(base_url, url))
    return execute_streaming_call().text


@_deserialize_text_result()
@_http_error_handling()
def get_token(session, base_url):
    """Get authorization token for accessing server content via browser"""
    return session.get(_full_url(base_url, "/getToken"))


@_deserialize_json_result(EnrichPredictJobState.from_json)
@_http_error_handling()
def predict(session, base_url, predict_params):
    """ Predict data using the generated model"""
    validation.assert_type(predict_params, PredictParams)
    return session.post(url=_full_url(base_url, '/api/predict'),
                        data=_to_json_filter_none_values_camel_case(predict_params),
                        headers={'content-type': 'application/json'}
                        )


@_deserialize_json_result(EnrichPredictJobState.from_json)
@_http_error_handling()
def enrich(session, base_url, enrich_params):
    """ Enrich data using the generated model"""
    validation.assert_type(enrich_params, EnrichParams)
    return session.post(url=_full_url(base_url, '/api/enrich'),
                        data=_to_json_filter_none_values_camel_case(enrich_params),
                        headers={'content-type': 'application/json'}
                        )


# 1.10 predict/enrich jobs
@_deserialize_json_result(EnrichPredictJobState.from_json)
@_http_error_handling()
def get_enrich_predict_job_state(session, base_url, job_id):
    return session.get(url=_full_url(base_url, '/api/jobState/' + job_id))


@_http_error_handling()
def cancel_job(session, base_url, job_id):
    """Works for all kinds of jobs"""
    return session.post(url=_full_url(base_url, '/api/cancelOrAbortJob/' + job_id))


@_deserialize_json_result(PredictionReportsJobState.from_json)
@_http_error_handling()
def generate_prediction_reports(session, base_url, predict_job_id, percent_of_population_to_plot):
    return session.post(
        url=_full_url(base_url, '/api/generatePredictionJobReports'),
        data=_dict_to_json_filter_none_values({
                'predictJobId': predict_job_id,
                'percentOfPopulationToPlot': percent_of_population_to_plot
            }),
        headers={'content-type': 'application/json'}
    )


@_deserialize_json_result()
@_http_error_handling()
def get_typer_errors_report_from_json(session, base_url, job_id):
    return session.get(_full_url(base_url, '/api/predictionReportFile/{}/typerErrorsReport.json'.format(job_id)))


@_deserialize_json_result(Evaluation.from_json)
@_http_error_handling()
def get_predict_evaluation(session, base_url, reports_job_id):
    return session.get("{0}/api/predictionReportFile/{1}/evaluation.json".format(base_url, reports_job_id))


@_deserialize_json_result(PredictionReportsJobState.from_json)
@_http_error_handling()
def get_prediction_reports_job_state(session, base_url, job_id):
    return session.get(url=_full_url(base_url, '/api/jobState/' + job_id))


@_http_error_handling()
def export_model_to_prediction_box(session, base_url, project_name, revision,
                                   prediction_box_url, auth_key = None,
                                   upload_extractor = None, upload_model = None, upload_contexts = None,
                                   overwrite_existing = None, override_target_group_name = None):
    return session.post(
        url=_full_url(base_url, '/api2/predictionBoxClient/uploadModel'),
        data = _dict_to_json_filter_none_values(
            {'project': project_name, 'revision': revision, 'baseRevision': revision,
             'predictionBoxUrl': prediction_box_url, 'authKey': auth_key,
             'uploadExtractor': upload_extractor, 'uploadModel': upload_model, 'uploadContexts': upload_contexts,
             'overwriteExisting': overwrite_existing, 'overrideTargetGroupName': override_target_group_name}),
        headers = {'content-type': 'application/json'}
    )

@_deserialize_json_result()
@_http_error_handling()
def get_supported_algorithms(session, base_url):
    """Get supported algorithms list"""
    return session.get(url=_full_url(base_url, '/api2/algorithms'))


@_deserialize_json_result(lambda json: BuildInfo(json['releaseNumber'], json['gitRevision']))
@_http_error_handling()
def get_build_info(session, base_url):
    """Get build info - release version, git revision"""
    return session.get(url=_full_url(base_url, '/buildInfo'))


@_deserialize_json_result()
@_http_error_handling()
def get_inputs_structure(session, base_url, project_name, revision):
    """Get pipeline input structure"""
    return session.get(url=_full_url(base_url, '/api/getInputStructure/{0}/{1}'.format(project_name, revision)))


# Environment


@_deserialize_json_result(lambda json: [Environment.from_json(i) for i in json])
@_http_error_handling()
def fetch_environments(session, base_url):
    return session.get(url=_full_url(base_url, '/api/v1/environments'))


@_deserialize_json_result(Environment.from_json)
@_http_error_handling()
def fetch_environment(session, base_url, environment_name):
    return session.get(url=_full_url(base_url, '/api/v1/environments/{0}'.format(environment_name)))


@_deserialize_json_result(Environment.from_json)
@_http_error_handling()
def add_environment(session, base_url, environment):
    return session.put(
        url=_full_url(base_url, '/api/v1/environments'),
        data=_to_json_filter_none_values_camel_case(environment),
        headers={'content-type': 'application/json'})


@_http_error_handling()
def delete_environment(session, base_url, environment_name):
    return session.delete(
        url=_full_url(base_url, '/api/v1/environments/{0}'.format(environment_name))
    )


@_deserialize_json_result(Environment.from_json)
@_http_error_handling()
def update_environment(session, base_url, environment):
    return session.post(
        url=_full_url(base_url, '/api/v1/environments/{0}'.format(environment.name)),
        data=_to_json_filter_none_values_camel_case(environment),
        headers={'content-type': 'application/json'})


# EnvironmentType


@_deserialize_json_result(lambda json: [EnvironmentType.from_json(i) for i in json])
@_http_error_handling()
def get_environment_types(session, base_url):
    return session.get(url=_full_url(base_url, '/api/v1/environmentTypes'))


@_deserialize_json_result()
@_http_error_handling()
def is_environment_type_exists(session, base_url, environment_type):
    return session.get(url=_full_url(base_url, '/api/v1/environmentTypes/{0}/exists'.format(environment_type.name)))


@_deserialize_json_result(EnvironmentType.from_json)
@_http_error_handling()
def add_environment_type(session, base_url, environment_type):
    return session.put(
        url=_full_url(base_url, '/api/v1/environmentTypes'),
        data=_to_json_filter_none_values_camel_case(environment_type),
        headers={'content-type': 'application/json'}
    )


@_deserialize_json_result(lambda json: [EnvironmentType.from_json(i) for i in json])
@_http_error_handling()
def delete_environment_type(session, base_url, environment_type):
    return session.delete(url=_full_url(base_url, '/api/v1/environmentTypes/{0}'.format(environment_type.name)))


# DeployGroup


@_deserialize_json_result(lambda json: [DeployGroup.from_json(i) for i in json])
@_http_error_handling()
def get_deployed_groups(session, base_url):
    return session.get(url=_full_url(base_url, '/api/v1/deployedGroups'))


@_deserialize_json_result(DeployGroup.from_json)
@_http_error_handling()
def publish_deploy_group(session, base_url, deploy_group, force):
    return session.post(
        url=_full_url(base_url, '/api/v1/deployedGroups/publish'),
        data=_dict_to_json_filter_none_values({
                'environmentName': deploy_group.env_name,
                'projectName': deploy_group.project_name,
                'projectRevision': deploy_group.project_revision,
                'force': force
                }),
        headers={'content-type': 'application/json'})


@_http_error_handling()
def remove_deploy_group(session, base_url, deploy_group):
    return session.delete(url=_full_url(base_url, '/api/v1/deployedGroups/{0}/{1}'.format(
        deploy_group.name, deploy_group.env_name)))


# EnvironmentHistory


@_deserialize_json_result(lambda json: [EnvironmentHistory.from_json(i) for i in json])
@_http_error_handling()
def get_environment_history(session, base_url, environment_name):
    return session.get(url=_full_url(base_url, '/api/v1/environmentHistoryRecords/{0}'.format(environment_name)))


@_deserialize_json_result(lambda json: [EnvironmentHistory.from_json(i) for i in json])
@_http_error_handling()
def get_all_environment_history(session, base_url):
    return session.get(url=_full_url(base_url, '/api/v1/environmentHistoryRecords'))


# World Knowledge
@_deserialize_json_result(lambda parsed_json: WorldKnowledgeResponse.from_json(parsed_json))
@_http_error_handling()
def get_world_knowledge_objects_metadata(session, base_url):
    return session.get(url=_full_url(base_url, '/api/v1/worldKnowledgeObjects'))


# Typing
@_deserialize_json_result(lambda schema: {input_kind: inputs for input_kind, inputs in schema.items()
                                          if input_kind in ['inputs', 'contextInputs']})
@_http_error_handling()
def get_inputs_schema(session, base_url, project_name, revision):
    return session.get(url=_full_url(base_url, '/analytics/modelInputSchema/{0}/{1}'.format(project_name,revision)))


@_deserialize_json_result()
@_http_error_handling()
def check_types(session, base_url, project_name, revision, input_name, input_provider,
                typers, take_rows, examples_per_column):
    return session.post(
        url=_full_url(base_url, '/api/blockingTyperErrorReport'),
        data=_to_json_filter_none_values_camel_case({
            'projectName': project_name,
            'revision': revision,
            'inputName': input_name,
            'input': input_provider,
            'typers': typers,
            'takeRows': take_rows,
            'examplesPerColumn': examples_per_column
        }),
        headers={'content-type': 'application/json'})