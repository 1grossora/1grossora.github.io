from ._utils import math
from pandas import DataFrame
import logging

log = logging.getLogger(__name__)


def generate_errors_data_frame(typer_error_report):
    rows = []
    for k, v in typer_error_report['columns'].items():
        t = ['Row {}: {}'.format(example['row'], example['value']) for example in v['examples']]
        rows.append([k, v['errors'], "{}%".format(math.calculate_percentage(v['errors'], typer_error_report['rowsSeen']))] + t)

    errors_data_frame = DataFrame(rows)
    errors_data_frame.columns = ['column', 'error_num', 'error_pct'] + ['example{}'.format(i) for i in
                                                                   range(1, len(errors_data_frame.columns) - 2)]

    if not sum(errors_data_frame['error_num']):
        errors_data_frame = errors_data_frame.drop(['error_pct'], axis=1)

    return errors_data_frame


def print_type_error_overview(typer_error_report):
    res = ''
    if typer_error_report:
        number_of_reports_with_errors = len([inp for inp in typer_error_report['inputs']
                                   if typer_error_report['inputs'][inp]['rowsWithErrors'] > 0])
        if number_of_reports_with_errors > 0:
            res += '\nStarting typing error report summary\n'
            res += '====================================\n'
            res += 'Typer errors detected in {} inputs\n'.format(number_of_reports_with_errors)
            for k in typer_error_report['inputs']:
                v = typer_error_report['inputs'][k]
                res += '{}:\n'.format(k)
                res += '\tRows processed: {}\n'.format(v['rowsSeen'])
                res += '\tRows with typer errors: {}\n'.format(v.get('rowsWithErrors'))
                res += '\tPercent of rows with typer errors: {}%\n'.format(
                    math.calculate_percentage(v['rowsWithErrors'], v['rowsSeen']))

            res += '\nCompleted typing error report summary\n'
            res += '=====================================\n'
    return res
