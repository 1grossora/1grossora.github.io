"""
:obj:`.WorldKnowledgeObject` is a class that represents world knowledge objects that are collected and stored.
These objects are discovered automatically on login.
Each object has a designated type of context as well as key columns that are assigned to it by a curator.
This allows easy usage as context as documented below. Additionally, they can be used as regular data frames
in other context types.
"""


class WorldKnowledge:
    """Accessor for world knowledge objects. An instance of this object is initialized on login and can be accessed
        directly from SDK session:

        >>> client = sparkbeyond.SparkBeyondClient(...)
        >>> client.world_knowledge.get.census

        Args:
            get(`ObjectsCollection`): allows accessing the objects by name. Each object can be accessed
                either by attribute with the corresponding name or by a key with the same name.
                Example:

                >>> client = sparkbeyond.SparkBeyondClient(...)
                >>> client.world_knowledge.get.census
                >>> client.world_knowledge.get['census']

                World Knowledge Object can be used as a context:

                .. code-block:: python

                    model = client.learn(
                                project_name='zipcode_project',
                                train_data=zip_data,
                                target='target',
                                context_datasets=client.world_knowledge.get.census
                            )
            list_all (:obj:`pandas.DataFrame`): a DataFrame containing the information about the available
                World Knowledge Objects

    """
    def __init__(self, get, list_all):
        self.get = get
        self.list_all = list_all


class _ObjectsCollection(object):
    def __init__(self, ds_metadata):
        self._name_to_metadata = {ds_metadatum.id: ds_metadatum for ds_metadatum in ds_metadata}
        for name, ds_metadatum in self._name_to_metadata.items():
            setattr(self, name, ds_metadatum)

    def __getitem__(self, key):
        return self._name_to_metadata[key]


class WorldKnowledgeObject:
    """Contains the metadata of a World Knowledge Object.
        Metadata contains information about the object, parameters allowing to download object's data and return a
        :obj:`pandas.DataFrame` holding the data.
        Additionally, metadata contains a recommendation for context to use the data with.
        It can be passed as a context directly to learn function.
        It's also possible to pass it as data to any of the contexts based on data and override the context
        recommendations.

        Args:
            id (str): id of the object
            name (str): human readable name of the object
            category (str): object category
            description (str): description of the data in the object
            context (:obj:`.WorldKnowledgeObject.WorldKnowledgeContext`): definition of the recommended context
            rows (long): number of row
            columns (int): number of columns
            size_mb (long): size of the original file in MB
            uploaded_by (str): name of the user who has uploaded the object
            updated_on (long): timestamp of when the object was last updated
    """

    class WorldKnowledgeContext:
        """Definition of the recommended context

            Args:
                key_columns (:obj:`list` of :obj:`.WorldKnowledgeObject.WorldKnowledgeObjectColumn`):
                    list of columns of recommended keys
                time_column (:obj:`.WorldKnowledgeObject.WorldKnowledgeObjectColumn`): recommended time column.
                    When time column is irrelevant, None
                context_type (str): type of the context. 2 types of contexts are currently supported: Lookup and
                    TimeSeries
        """

        def __init__(self, key_columns, time_column, context_type):
            self.key_columns = key_columns
            self.time_column = time_column
            self.context_type = context_type

        def __repr__(self):
            return "{}(key_columns: {}{})" \
                .format(self.context_type, self.key_columns,
                        "time_column: {}".format(self.time_column) if self.time_column is not None else "")

    class WorldKnowledgeObjectColumn:
        """Definition of the column

            Args:
                name (str): name of the column
                column_type (str): type of the column, as detected by server.
        """

        def __init__(self, name, column_type):
            self.name = name
            self.column_type = column_type

        def __repr__(self):
            return "{}: {}".format(self.name, self.column_type)

    class WorldKnowledgeContextType:
        LOOKUP = "Lookup"
        """Look Up context"""
        TIME_SERIES = "TimeSeries"
        """Time Series context"""

    def __init__(self, id, name,
                 category, description,
                 context,
                 rows, columns, size_mb,
                 uploaded_by, updated_on,
                 url, user_session):
        self.id = id
        self.name = name
        self.category = category
        self.description = description
        self.context = context
        self.rows = rows
        self.columns = columns
        self.size_mb = size_mb
        self.uploaded_by = uploaded_by
        self.updated_on = updated_on
        self._url = url
        self._data = None
        self._user_session = user_session
        self._context_def = None

    def data(self):
        """
        Returns: (:obj:`pandas.DataFrame`) containing the data

        """
        import pandas as pd
        if self._data is None:
            local_path = self._user_session.download_world_knowledge_object_data(self.id)
            self._data = pd.read_csv(local_path, sep=',')
            return self._data
        else:
            return self._data

    def head(self, rows=5):
        return self.data().head(rows)

    @property
    def _as_context(self):
        from .sdk_dtos import Contexts, _DataContext, WebFileInput
        if self._context_def is None:
            context_type_dict = {
                WorldKnowledgeObject.WorldKnowledgeContextType.LOOKUP: Contexts._ContextType.LOOKUP_TABLES,
                WorldKnowledgeObject.WorldKnowledgeContextType.TIME_SERIES: Contexts._ContextType.TIME_SERIES,
            }
            cont_type = context_type_dict[self.context.context_type]
            if cont_type == Contexts._ContextType.TIME_SERIES and self.context.key_columns:
                cont_type = Contexts._ContextType.TIME_SERIES_MAP
            self._context_def = _DataContext(
                data=WebFileInput(self._url, self.name),
                name=self.id,
                context_types=[cont_type],
                key_columns=[col.name for col in self.context.key_columns],
                time_column=self.context.time_column.name if self.context.time_column is not None else None)

            return self._context_def
        else:
            return self._context_def

    @property
    def _as_data_input(self):
        from .sdk_dtos import WebFileInput
        return WebFileInput(self._url, self.id)

    def __repr__(self):
        import datetime
        return """
            ID: {}
            Name: {}
            Category: {}
            Description: {}
            Context: {}
            Rows: {}
            Columns: {}
            Size: {} MB
            Uploaded By: {}
            Updated On: {}""".format(self.id, self.name, self.category, self.description,
                                     self.context,
                                     self.rows, self.columns, self.size_mb,
                                     self.uploaded_by, datetime.datetime.fromtimestamp(self.updated_on / 1000.0))
