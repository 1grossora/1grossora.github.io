import logging

log = logging.getLogger(__name__)


class _Settings(object):
    """ Global settings """

    def __init__(self):
        self._verbose = False

    @property
    def verbose(self):
        return self._verbose

    @verbose.setter
    def verbose(self, value):
        from . import _logging_config

        if value is self._verbose:
            log.info("Verbose logging is already set to %s", self._verbose)
        else:
            _logging_config.verbose(value)
            self._verbose = value
            log.info("Verbose logging is turned %s", 'On' if self._verbose else 'Off')

settings = _Settings()
""" Global settings

verbose - set to True to enable verbose logging. Verbose logging includes HTTP traffic and is very useful
    for debugging connection issues.

Examples:

>>> from sparkbeyond import settings
>>> settings.verbose = True
"""
