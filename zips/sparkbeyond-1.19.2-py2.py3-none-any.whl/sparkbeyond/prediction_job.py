import logging
import time
import sys
from pandas import read_csv

from . import _type_error_report
from ._internal_api import OperationFailure
from ._internal_api.api_dtos import EnrichPredictJobState

log = logging.getLogger(__name__)


class PredictionJob:
    """A handler for monitoring and getting the result of prediction job

        Args:
            job_id (str): prediction job id
    """

    def __init__(self, user_session, job_id, total_rows=None):
        self.user_session = user_session
        self.job_id = job_id
        self.total_rows = total_rows
        self.data = None
        self._report_jobs_cache = {}

    def _print_state(self, state):
        """Print the state to system out

                Args:
                    state (EnrichPredictJobState): job state.
            """
        if state.is_enqueued():
            log.info('Prediction job is waiting in queue')
        elif state.is_running():
            if state.status.built_contexts is None or state.status.built_contexts is False:
                log.info("Prediction job is running. Parsing contexts...")
            else:
                total_rows_message = "out of {0} ".format(self.total_rows) if self.total_rows is not None else ""
                sys.stdout.write("\rPrediction job is running. So far processed {0} {1}rows"
                                 .format(state.status.processed_rows,
                                         total_rows_message))
                sys.stdout.flush()
        elif state.is_completed():
            def _timestamp_to_string(timestamp):
                import datetime
                return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

            if state.result.is_succeeded():
                log.info(_type_error_report.print_type_error_overview(state.status.typer_errors_report))

                total_rows_message = "out of {0} ".format(self.total_rows) if self.total_rows is not None else ""
                log.info("\nPrediction has finished successfully. Processed %s %s rows. Started: %s. Ended: %s",
                         state.status.processed_rows, total_rows_message,
                         _timestamp_to_string(state.started_millis), _timestamp_to_string(state.ended_millis))
            else:
                log.error("\nPrediction failed: %s. Worker ID: %s. Started: %s. Ended: %s.",
                          state.result.error, state.worker_id,
                          _timestamp_to_string(state.started_millis), _timestamp_to_string(state.ended_millis)),
        else:
            log.error("Unexpected job state:", state)

    def _execute_reports_generation(self, percent_of_population_to_plot=None):
        def print_current_evaluation_state(state):
            if state.is_enqueued():
                log.info("Prediction reports job is waiting in queue")
            elif state.is_running():
                log.info("Prediction reports job is running...")
            elif state.is_completed():
                if state.result.is_succeeded():
                    log.info("Prediction reports were generated successfully.")
                else:
                    raise(OperationFailure("Prediction reports generation failed:", state.result.error))
            else:
                raise(Exception("Unexpected job state:", state))

        cached_job_id = self._report_jobs_cache.get(percent_of_population_to_plot)

        if cached_job_id is not None:
            state = self.user_session.get_prediction_reports_job_state(cached_job_id)
            if state is not None and state.is_completed():
                return cached_job_id
            else:
                del self._report_jobs_cache[percent_of_population_to_plot]

        state = self.user_session.generate_prediction_reports(
            self.job_id,
            percent_of_population_to_plot=percent_of_population_to_plot)
        report_generation_job_id = state.job_id

        while not state.is_completed():
            time.sleep(5)
            state = self.user_session.get_prediction_reports_job_state(report_generation_job_id)
            print_current_evaluation_state(state)

        if state.result.is_succeeded():
            self._report_jobs_cache[percent_of_population_to_plot] = report_generation_job_id
            return report_generation_job_id
        else:
            raise OperationFailure("Prediction failed: {0}".format(state.result.error))

    def current_status(self):
        """Get prediction job status - Started/Finished, number of lines processed, etc."""
        state = self.user_session.get_enrich_predict_job_state(self.job_id)
        self._print_state(state)

    def get_data(self, local_file_name=None, run_blocking=True):
        """Get prediction result

        Args:
            local_file_name (str): local file name for saving the result
            run_blocking (bool): if True block until the result is ready, otherwise return the data (or None if data
                is not currently available) immediately

        Returns:
            :obj:`pandas.DataFrame`: If `run_blocking` is True, block until the job finishes while showing \
                processed rows counter, and return the result when available. If `run_blocking` is False \
                return the data if available, else return None
        """

        output_name = local_file_name if local_file_name is not None else "predicted-" + self.job_id

        if self.data is not None:
            return self.data
        elif run_blocking:
            time.sleep(1)
            state = self.user_session.get_enrich_predict_job_state(self.job_id)
            if not state.is_completed():
                log.info("Blocking until prediction result is available.")

            while not state.is_completed():
                time.sleep(5)
                state = self.user_session.get_enrich_predict_job_state(self.job_id)
                self._print_state(state)

            if state.result.is_succeeded():
                try:
                    local_path = self.user_session.download_job_result(self.job_id, output_name + ".tsv.gz")
                    self.data = read_csv(local_path, sep='\t', index_col=None)
                    return self.data
                except OperationFailure as e:
                    raise OperationFailure("Failed to download prediction result: {0}".format(e.message))
            else:
                raise OperationFailure("Prediction failed: {0}".format(state.result.error))
        else:
            log.info("Data isn't available locally. Use run_blocking=TRUE to get the data when prediction is ready")
            return None

    def job_reports(self):
        """Show interactive list of the available predict job reports -
        enter a report number to browse to the report."""
        state = self.user_session.get_enrich_predict_job_state(self.job_id)
        report_files_list = state.result.success['reportFilenames'] \
            if state.result.success['reportFilenames'] is not None else []

        if any('typerErrorsReport.json' in i for i in report_files_list):
            report_files_list.remove('typerErrorsReport.json')

        report_files = dict(enumerate(report_files_list, start=1))

        for num, name in report_files.items():
            print("[{0}] {1}".format(num, name))
        choice = raw_input('Enter a number of report to show or <enter> otherwise: ')
        try:
            report_name = report_files[int(choice.strip())]
            log.info("Showing %s", report_name)
            self.user_session.show_prediction_report(self.job_id, report_name)
        except Exception as e:
            print("Invalid input, should be a number between 1 and {}".format(report_files.__len__()))

    def scoring_reports(self, percent_of_population_to_plot=None,
                        download_reports=False, downloaded_file_name="prediction_reports"):
        """Show interactive list of the available predict scoring reports - enter a report number to browse to
            the report.

            Args:
                percent_of_population_to_plot (float): percentage of population for lift plots. Defaults to 0.2.
                download_reports (bool): set to True in order to download an archive file containing all the reports.
                    Interactive list reports will not be shown in this case.
                downloaded_file_name (str): changes the downloaded reports archive file name,
                    when :attr:`download_reports` is set to True, else is not used.

        """
        completed_reports_generation_job_id = self._execute_reports_generation(percent_of_population_to_plot)

        if download_reports:
            local_path = self.user_session.download_job_result(completed_reports_generation_job_id, downloaded_file_name + ".tsv.gz")
            log.info("Predition scoring reports were downloaded successfully to {0}".format(local_path))
        else:
            state = self.user_session.get_prediction_reports_job_state(completed_reports_generation_job_id)
            report_files_list = state.result.success['createdFilenames']
            report_files = dict(enumerate(report_files_list, start=1))

            for num, name in report_files.items():
                print("[{0}] {1}".format(num, name))
            choice = raw_input('Enter a number of report to show or <enter> otherwise: ')
            try:
                report_name = report_files[int(choice.strip())]
                log.info("Showing %s", report_name)
                self.user_session.show_prediction_report(completed_reports_generation_job_id, report_name)
            except Exception as e:
                print("Invalid input, should be a number between 1 and {}".format(report_files.__len__()))

    def evaluate(self):
        """Returns an evaluation object containing various information on the run,
         including evaluation metric that was used, evaluation score, precision, confusion matrix,
         number of correct and incorrect instances, AUC information and more.
         """
        completed_reports_generation_job_id = self._execute_reports_generation()
        evaluation = self.user_session.get_predict_evaluation(completed_reports_generation_job_id)
        print(evaluation.summary)
        return evaluation

    def cancel(self):
        """Cancel the job"""
        self.user_session.cancel_job(self.job_id)
