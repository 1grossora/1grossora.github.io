import os.path
import tempfile
import csv

from . import sdk_dtos
import logging
import hashlib

from shutil import copyfile
import timeit

from sparkbeyond._internal_api import ResourceId, UserSession
from sparkbeyond._utils import validation

log = logging.getLogger(__name__)


def _split_compound_ext(path):
    """Split extension, including compound extensions.
    For example for file name: "file_name.tsv.gz" return (file_name, tsv.gz),
    for "file_name.tsv" return (file_name, tsv).

    Args:
        path (str): A path to file

    Returns:
        (path_without_ext, compound_ext)
    """
    name, ext = os.path.splitext(path)
    if len(ext) == 0:
        return name, ''
    else:
        rec_name, rec_ext = _split_compound_ext(name)
        return rec_name, rec_ext + ext


def hash_data_frame(df):
    """Calculate hash for a `pandas.DataFrame`

        Args:
            df (`pandas.DataFrame): A data frame

        Returns:
            Hash value
        """


    def iterate_data_frame_in_batches(df, batch=10000):
        for pos in range(0, len(df), batch):
            yield df[pos:pos + batch]

    start_time = timeit.default_timer()
    hash_md5 = hashlib.md5()
    hash_md5.update(bytes(df.columns.names))
    for batch in iterate_data_frame_in_batches(df):
        hash_md5.update(batch.to_msgpack())

    elapsed = timeit.default_timer() - start_time
    log.debug('Hash calculation took %f seconds', elapsed)
    return hash_md5.hexdigest()


def _hash_file_content(path):
    """Calculate hash for a file

    Args:
        path (str): A path to a file

    Returns:
        Hash value
    """
    hash_md5 = hashlib.md5()
    log.debug('Calculating a hash for %s', path)
    start_time = timeit.default_timer()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    calculated_hash = hash_md5.hexdigest()

    elapsed = timeit.default_timer() - start_time
    log.debug('Calculated a hash for %s. Calculation took %d seconds', path, elapsed)

    return calculated_hash


def _add_hash_to_file_name(path, file_hash=None, in_place=False):
    """Add a hash to the file name, separated by '-' from the original name, using the original file extension.

    Args:
        path (str): A path to the original file.
        file_hash (str): Hash value. Optional - if not specified, hash will be calculated.
        in_place (bool): Optional, if True - rename the original file, if False - copy the file to a temp dir
            and change the name.

    Returns:
        The path to the result file
    """
    file_name, file_extension = _split_compound_ext(os.path.basename(path))
    calculated_hash = file_hash or _hash_file_content(path)
    file_name_with_hash = "{0}-{1}{2}".format(file_name, calculated_hash, file_extension)

    if in_place:
        original_dir = os.path.dirname(path)
        path_with_hash = os.path.join(original_dir, file_name_with_hash)
        os.rename(path, path_with_hash)
        return path_with_hash
    else:
        path_with_hash = os.path.join(tempfile.gettempdir(), file_name_with_hash)
        copyfile(path, path_with_hash)
        return path_with_hash


def upload_file_to_server(session, local_path, project_name, overwrite=False):
    """File upload. By default the file will not be uploaded if the file already exists on server.

    Args:
        session: authenticated user session
        local_path: local path to file
        project_name: project name
        overwrite (bool): if True, the file will be uploaded even when the file already exists on server

    Returns:
        ResourceId identifier of this resource on server
    """
    basename = os.path.basename(local_path)
    existing_file = session.file_exists(project_name, basename)

    if existing_file is not None and not overwrite:
        log.debug('The file: %s already exists on the server, use overwrite = True to replace it', basename)
        return existing_file
    else:
        return session.upload_file(project_name, local_path)


def upload_data_frame_to_server(project_name, session, data_frame_input):
    """Upload DataFrame content

        Args:
            project_name(str): Project name.
            session (`UserSession`): Authenticated user session.
            data_frame_input (:obj:`sparkbeyond.DataFrameInput`): Data frame input object.

        Returns:
            `ResourceId` identifier of this resource on server
    """
    assert isinstance(data_frame_input, sdk_dtos.DataFrameInput), 'data should be an instance of DataFrameInput'

    df_hash = hash_data_frame(data_frame_input.data_frame)
    file_name = "{}-{}.tsv.gz".format(data_frame_input.name.replace(" ", "-"), df_hash)

    existing_file = session.file_exists(project_name, file_name)
    if existing_file is not None:
        log.debug('The file: %s already exists on the server, skipping upload', file_name)
        return existing_file
    else:
        tempdir = tempfile.mkdtemp()
        local_path = os.path.join(tempdir, file_name)

        log.info('Saving %s to %s before upload', data_frame_input.name, local_path)

        start_time = timeit.default_timer()

        try:
            data_frame_input.data_frame.to_csv(local_path, index=False, sep="\t", quoting=csv.QUOTE_NONNUMERIC,
                                               compression='gzip')
        except UnicodeEncodeError:
            log.info(
                'Cannot save compressed csv file due to encoding error, try to save uncompressed with utf-8 encoding')
            data_frame_input.data_frame.to_csv(local_path, index=False, sep="\t", quoting=csv.QUOTE_NONNUMERIC,
                                               encoding='utf-8')

        elapsed = timeit.default_timer() - start_time
        log.info('File %s size %d bytes. Executed in %d seconds',
                 local_path, os.path.getsize(local_path), elapsed)

        file_reference = session.upload_file(project_name, local_path)
        os.remove(local_path)

        return file_reference


def upload_data_file_to_server(project_name, session, data_file_input, overwrite=False, use_hash=True):
    """Upload data file

            Args:
                project_name(str): Project name.
                session (`UserSession`): Authenticated user session.
                data_file_input (:obj:`sparkbeyond.DtaFileInput`): Data file input object.
                overwrite (bool): If True, the file will be uploaded even when the file already exists on server.
                use_hash (bool): If True, calculate a hash of the content. It's used to prevent unnecessary upload.

            Returns:
                `ResourceId` identifier of this resource on server
    """
    assert isinstance(data_file_input, sdk_dtos.DataFileInput), 'data should be an instance of DataFileInput'
    validation.assert_file_exists(data_file_input.file_path)

    final_path = data_file_input.file_path if not use_hash else _add_hash_to_file_name(data_file_input.file_path)

    file_reference = upload_file_to_server(session, final_path, project_name, overwrite=overwrite)
    os.remove(final_path)
    return file_reference
