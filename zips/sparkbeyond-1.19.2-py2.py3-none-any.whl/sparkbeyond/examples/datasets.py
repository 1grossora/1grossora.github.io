from . import _examples_loader


def titanic():
    """Titanic passengers data"""
    return _examples_loader.load('titanic_train.tsv')


def sentiment_lexicon():
    """Words sentiment score"""
    return _examples_loader.load('SentimentLexicon_Hu_Liu_KDD2004.tsv')


def tweets_sentiment():
    """Tweets with a sentiment score"""
    return _examples_loader.load('tweets_sentiment.tsv')