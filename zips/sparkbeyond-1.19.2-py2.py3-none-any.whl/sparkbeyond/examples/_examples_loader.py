from pandas import read_csv
import os

_this_dir, _this_filename = os.path.split(__file__)
_DATA_PATH = os.path.join(_this_dir, "data")


def load(file_name):
    file_path = os.path.join(_DATA_PATH, file_name)
    return read_csv(file_path, sep='\t')
