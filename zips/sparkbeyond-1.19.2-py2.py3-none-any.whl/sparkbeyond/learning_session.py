from . import _sdk_actions
import logging
from .prediction_job import PredictionJob
from .enrichment_job import EnrichmentJob
from .sdk_dtos import DataFrameInput
from .sdk_dtos import LearningDefinition
from ._sdk_actions import LearningJobStatus

log = logging.getLogger(__name__)


class LearningSession:
    """Learning session (model) analysis and usage for prediction/enrichment

        Can be created in 2 ways:

        - By creating a new learning job using :meth:`.SdkSession.learn`
        - By loading the previously executed learning job using :meth:`.SdkSession.review`
    """

    def __init__(self,
                 user_session,
                 project_name,
                 revision,
                 job_id):
        # Note: Create by SdkSession. Not supposed to be called instantiated directly,
        self._user_session = user_session
        self.project_name = project_name
        self.revision = revision
        self.job_id = job_id
        self._schema = None

    def evaluate(self):
        """Evaluation of the generated model on a test set

            Returns:
                :obj:`.EvaluationResult`: evaluation stats
        """
        evaluation = _sdk_actions.evaluate(self._user_session, self.project_name, self.revision)
        log.info("Model evaluation summary: %s" % evaluation.summary)
        return evaluation

    def features(self):
        """Get features discovered in this learning session

            Returns:
                :obj:`pandas.DataFrame`: data frame containing the features and related stats
        """
        return _sdk_actions.features(self._user_session, self.project_name, self.revision)

    def web_view(self):
        """Open a a web view for this learning session in a browser"""
        _sdk_actions.web_view(self._user_session, self.project_name, self.revision)

    def export_model(self, include_contexts=True):
        """Export model for prediction box.

        If prediction requires to supply ALL new contexts and no original contexts are needed,
        download of the contexts can be skipped be setting include_contexts to False

        Args:
            include_contexts (bool): set to False to disable contexts export
        Returns:
            dictionary of created files
        """
        return _sdk_actions.export_model_for_prediction(self._user_session, self.project_name, self.revision,
                                                        include_contexts)

    def export_model_to_prediction_box(self, prediction_box_url, auth_key=None, upload_contexts=None,
                                       overwrite_existing=None, override_target_group_name=None):
        """Export model to prediction box.

            Upload feature extractor, model and contexts to prediction box from discovery platform server

            Args:
                prediction_box_url (str): base url of the prediction box
                    the data frame with a specified name.
                auth_key (str): prediction box authorization key.
                upload_contexts (bool): if True, contexts will be uploaded to prediction box. It's useful to set
                    this flag to False if the contexts are large and don't change between learning iterations.
                    Defaults to True.
                overwrite_existing (bool): if True, existing model with the same name in prediction box will be
                    overwritten. Defaults to True.
                override_target_group_name (str): name of the group (model) created in prediction box.
                    Defaults to None - in this case the name project name will be used as the name of the group.
        """
        _sdk_actions.export_model_to_prediction_box(
            self._user_session, self.project_name, self.revision,
            prediction_box_url, auth_key=auth_key, upload_contexts=upload_contexts,
            overwrite_existing=overwrite_existing, override_target_group_name=override_target_group_name)

    def relearn_with_new_inputs(self, inputs, show_web_view=True, run_blocking=True):
        """Start a new learning process base on this learning with new input sources

            Args:
                inputs (:obj:`dict` of :obj:`str` to :obj:`.DataInput`): dictionary of the new input sources.
                    Key is the name of the input in the pipeline, as it appears in the web view.
                    Value is the new data, represented as either :obj:`.DataInput` object or :obj:`pandas.DataFrame`.
                show_web_view (bool): open the learning pipeline in browser during training. Defaults to True.
                run_blocking (bool): return only after the learning has finished. Defaults to True.
        """
        learning_job = _sdk_actions.relearn_with_new_inputs(self._user_session, self.project_name,
                                                            inputs, self.revision, show_web_view=show_web_view)

        if run_blocking:
            log.info("You are now running in a Blocking Mode")
            job_status = _sdk_actions.wait_for_learn_job_to_finish(
                self._user_session,
                learning_job.project_name,
                learning_job.revision,
                learning_job.job_id)
            if job_status.status == LearningJobStatus.Statuses.FAILED:
                raise Exception("Learning failed with error: %s", job_status.error)

        return LearningSession(user_session=self._user_session,
                               project_name=learning_job.project_name,
                               revision=learning_job.revision,
                               job_id=learning_job.job_id)

    def get_definition(self):
        inputs_schema = _sdk_actions.get_inputs_structure(user_session=self._user_session,
                                                          project_name=self.project_name, revision=self.revision)
        return LearningDefinition(inputs_schema=inputs_schema)

    def predict(self,
                data,
                include_originals=None,
                include_enriched=None,
                include_explanations=None,
                columns_white_list=None,
                output_name="predicted",
                lines_for_context_match_report=None,
                context_data=None,
                run_blocking=True,
                **kw):
        """Predict for new data based on this model

        Args:
            data (pandas.DataFrame or :obj:`.DataInput`): data to predict on. :obj:`.DataFrameInput` can be used
                to associate the data frame with a specified name.
            include_originals(bool): set to True to include the original columns in the result. Defaults to False.
            include_enriched (bool): set to True to include the enriched columns in the result. Defaults to False.
            include_explanations (bool): set to True to include prediction explanations. Defaults to False.
            columns_white_list (:obj:`list` of :obj:`str`): columns to use for prediction. By default all columns are used.
            output_name (str): name of the file to save the results to. The file will be saved in the working directory.
            lines_for_context_match_report (int): number of rows to use for context match report. Defaults to 50000.
            context_data (:obj:`list` of `Context`): contexts to use for prediction. If not specified, contexts used
                to train the model are used. See the documentation for :obj:`.Contexts`.
            run_blocking (bool): if True, returns Prediction object when the result is available, otherwise
                returns immediately

        Returns:
            :class:`sparkbeyond.PredictionJob`: representation of the predict job
        """
        predict_job_state = _sdk_actions.predict(self._user_session,
                                                 self.project_name,
                                                 self.revision,
                                                 data,
                                                 include_originals,
                                                 include_enriched,
                                                 include_explanations,
                                                 columns_white_list,
                                                 lines_for_context_match_report,
                                                 context_data,
                                                 # Experimental, not documented on purpose
                                                 kw.get('include_typer_error_report'))

        def guess_data_size(data_input):
            from pandas import DataFrame
            if isinstance(data_input, DataFrame):
                return len(data_input.index)
            elif isinstance(data_input, DataFrameInput):
                return len(data_input.data_frame.index)
            else:
                return None

        prediction = PredictionJob(self._user_session, predict_job_state.job_id, guess_data_size(data))
        if run_blocking:
            prediction.get_data(output_name)
        return prediction

    def enrich(self,
               data,
               feature_count=None,
               include_originals=None,
               columns_white_list=None,
               output_name="enriched",
               lines_for_context_match_report=None,
               context_data=None,
               run_blocking=True,
               **kw):
        """Enrich new data with features generated using this model

        Args:
            data (pandas.DataFrame or :obj:`.DataInput`): data to enrich. :obj:`.DataFrameInput` can be used
                to associate the data frame with a specified name.
            feature_count (int): the number of features to include in the output.
            include_originals (bool): set to True to include the original columns in the result. Defaults to False.
            columns_white_list (:obj:`list` of :obj:`str`): columns to use for generating features.
            output_name (str): name of the file to save the results to. The file will be saved in the working directory.
            lines_for_context_match_report (int): number of rows to use for context match report. Defaults to 50000.
            context_data (:obj:`list` of `Context`]): contexts to use for enrichment. If not specified, contexts used
                to train the model are used. See the documentation for :obj:`.Contexts`.
            run_blocking (bool): if True, returns Enrichment object when the result is available, otherwise
                returns immediately

        Returns:
            :obj:`sparkbeyond.EnrichmentJob`: representation of the enrich job
        """

        def guess_data_size(data_input):
            from pandas import DataFrame
            if isinstance(data_input, DataFrame):
                return len(data_input.index)
            elif isinstance(data_input, DataFrameInput):
                return len(data_input.data_frame.index)
            else:
                return None

        enrich_job_state = _sdk_actions.enrich(self._user_session,
                                               self.project_name,
                                               self.revision,
                                               enrich_data=data,
                                               feature_count=feature_count,
                                               include_originals=include_originals,
                                               column_white_list=columns_white_list,
                                               lines_for_context_match_report=lines_for_context_match_report,
                                               context_data=context_data,
                                               # Experimental, not documented on purpose
                                               include_typer_error_report=kw.get('include_typer_error_report'))

        enrichment = EnrichmentJob(self._user_session, enrich_job_state.job_id, guess_data_size(data))
        if run_blocking:
            enrichment.get_data(output_name)
        return enrichment

    def cancel(self):
        """Cancel a queued / running job of this model"""
        self._user_session.cancel_job(self.job_id)

    def get_schema(self):
        if not self._schema:
            self._schema = _sdk_actions.get_inputs_schema(self._user_session, self.project_name, self.revision)

        def sanitize_schema(schema):
            import copy
            dic = copy.deepcopy(schema)
            for k, v in schema.items():
                if k == "jsonClass":
                    dic["type"] = v.split('.')[-1].replace('Typer','')
                    del dic[k]
                elif k == "defaultValue" and isinstance(dic[k], dict):
                    dic[k] = next(iter(dic[k].values()))
                elif k == "unquote" or k == "trim" or k == "rawDefaultValue":
                    del dic[k]
                elif isinstance(v, dict):
                    dic[k] = sanitize_schema(v)
            return dic

        return sanitize_schema(self._schema)

    def check_types(self, input_name, data, file_escaping=None, file_encoding=None, take_rows=None,
                    examples_per_column=None):

        self.get_schema()
        inputs_by_name = {in_name: input for inputs in self._schema.values() for in_name, input in inputs.items()}
        if input_name not in inputs_by_name.keys():
            raise Exception("Could not find provided input name in schema. "
                            "Valid input names are: {0}".format(','.join(inputs_by_name.keys())))

        typers = inputs_by_name[input_name]

        return _sdk_actions.check_types(self._user_session, self.project_name, self.revision, input_name, data,
                                        typers, file_escaping,
                                        file_encoding, take_rows, examples_per_column)
