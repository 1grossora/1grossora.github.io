def calculate_percentage(numerator, denominator):
    return round(100 * (float(numerator) / denominator), 2)