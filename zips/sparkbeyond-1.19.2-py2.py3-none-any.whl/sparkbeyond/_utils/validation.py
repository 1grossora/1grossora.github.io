import os


def assert_type(obj, expected_type, message=None):
    if obj is not None and not isinstance(obj, expected_type):
        raise TypeError("{0} should be of type: {1} but was {2}".format(obj,
                                                                        expected_type if message is None else message,
                                                                        type(obj)))


def assert_one_of_types(obj, expected_types, message=None):
    if obj is not None and all(not isinstance(obj, t) for t in expected_types):
        raise TypeError("{0} should be one of the following types: {1}".format(
            obj, expected_types if message is None else message))


def assert_file_exists(path, message=None):
    if not os.path.exists(path):
        raise ValueError("File doesn't exist at: {0}".format(path) if message is None else message)


def wrap_with_list_if_needed(param):
    if param is None:
        return None
    elif not isinstance(param, (list, tuple)):
        return [param]
    else:
        return param
