from functools import wraps
from ._utils import validation
from pandas import DataFrame
import logging
log = logging.getLogger(__name__)


class EmptyValuePolicy:
    """Defines how empty values in numeric columns in the original data are being handled."""

    MEDIAN = "Median"
    """Median value of a column"""
    AVERAGE = "Average"
    """Average value of a column"""
    NAN = "NaN"
    """Not a number"""
    DOUBLE_NAN = "DoubleNaN"  # current default in server #todo: description
    """Double columns are filled with NaN and Integer columns are filled with zero. This is the default."""
    NEGATIVE_INFINITY = "NegativeInfinity"
    """Negative infinity"""


class PreProcessing:
    """PreProcessing settings.

        Args:
            lines_for_type_detection (int): Maximum number of lines that should be used for type detection.
                10000 by default.
            empty_value_policy (str): Controls how empty values in numeric columns
                in the input data are being handled. On of the values from :class:`.EmptyValuePolicy`.
                DoubleNan by default.
    """

    def __init__(self,
                 # todo: probably redundant
                 file_escaping=None,
                 file_encoding=None,
                 lines_for_type_detection=None,
                 empty_value_policy=None):
        # empty_value_policy default: EmptyValuePolicy.DOUBLE_NAN
        self.fileEscaping = file_escaping
        self.fileEncoding = file_encoding
        self.linesForTypeDetection = lines_for_type_detection
        self.emptyValuePolicy = empty_value_policy


class TimeWindowDefinition:
    """Sliding window definition.

    Sliding window has to be based on a date column name from training set

    Args:
        date_col (str): The column name in training/predict set that will be used as a base for sliding window.
        window (int): The window length (numeric). 100 by default.
        unit (str): The window length unit. Should be one of: "Seconds", "Minutes", "Hours", "Days", "Years".
            "Days" by default.
        key_col (str): An optional key for the sliding window. None by default.
        relative_time (bool): indicator for whether the time series should be coded with absolute timestamps
            or relative to the last point. In this case all time stamps will be negative using the defined time unit
            (e.g. -10 days). True by default.
        sample (int): Allows defining the maximum number of time points to be included in each time series.
            Random points are sampled from the time series to reduce the time series resolution
            in order to better capture global trends and increase runtime performance. 100 by default.
        offset (int): Allows defining an additional time gap between that will be masked for the feature search.
            The entire time series will be shifted accordingly using the time window that was picked. 0 by default.
        allow_historical_stats (bool): when true, statistics for various historical quantities of the corresponding key
            will be calculated over the entire history (e.g. the average historical price of an item since
            the beginning of time), as opposed to just within the time-window (e.g. the average price for an item
            within the past 3 days). True by default.
        natural_modality (str): useful if there are natural time cycle dependencies such as daily or monthly.
            Multiple will cause the system to try them all and None to try none.
            Possible values: None, Hour_Of_Day, Day_Of_Week, Month_Of_Year, Multiple. None by default.
        apply_modality_filter (bool): indicator for whether to use only dates with the same modality
            as the date column, or search on both the whole window and the modal version. False by default.
        remove_key_column (bool): a boolean indication for whether to remove the key column from the main training set.
            Default to false.
        remove_date_column (bool): a boolean indication for whether to remove the date column from the main
            training set. Default to false.

    """

    def __init__(self,
                 date_col,
                 key_col=None,
                 window=None,
                 unit=None,
                 relative_time=True,
                 sample=None,
                 offset=0,
                 allow_historical_stats=None,
                 natural_modality=None,
                 apply_modality_filter=None,
                 remove_key_column=False,
                 remove_date_column=False):
        self.dateColumn = date_col
        self.keyColumn = key_col
        self.windowSize = window
        self.timeUnit = unit
        self.relativeTime = relative_time
        self.sampleSize = sample
        self.offsetFromTarget = offset
        self.allowHistoricalStats = allow_historical_stats
        self.naturalModality = natural_modality
        self.applyModalityFilter = apply_modality_filter
        self.removeKeyColumn = remove_key_column
        self.removeDateColumn = remove_date_column


class ProblemDefinition:
    """Problem definition settings.

        Args:
            force_regression (bool): Force the problem to be regression problem instead of classification.
                Default is to choose the best problem definition based on the target.
            weight_column (string): Name of of one of the column that indicate a weighting that is assigned
                to each example. NA by default.
            weight_by_class (bool): Adds a weight column with values inverse proportional to the frequency of the class.
                False by default.
            train_test_split_ratio (float): float value in [0,1] to split the train file data in order
                to keep some data for test. 0.8 by default. Ignored if test filename was provided.
            temporal_split_column (string): A column name containing temporal information by which the data
                will be split to train and test based on `train_test_split_ratio`.
            partition_column (string): A column name containing information by which the data will be split
                to tain/test/validation set. Allowed values: "Train", "Validation", "Test".
            time_windows_definition (:obj:`list` of :class:`.TimeWindowDefinition`): Sliding window has to be based on a date
                column name from training set. Has to be configured when using :obj:`.Contexts.TimeSeries` and
                :class:`.Contexts.TimeSeriesMap`
    """

    def __init__(self,
                 force_regression=None,
                 weight_column=None,
                 weight_by_class=None,
                 train_test_split_ratio=None,
                 temporal_split_column=None,
                 partition_column=None,
                 time_windows_definition=None):
        self.forceRegression = force_regression
        self.weightColumn = weight_column
        self.weightByClass = weight_by_class
        self.trainTestSplitRatio = train_test_split_ratio
        self.temporalSplitColumn = temporal_split_column
        self.partition_column = partition_column
        self.time_windows_definition = time_windows_definition

class ProjectRevision:
    """
    Project Revision
    """

    ROOT=0
    """
    Represent project root revision  
    """

class FeatureGeneration:
    """Feature generation settings.

        Args:
            max_features_count (:obj:`list` of int): A list of integers indicating how many features]
                should be created by the SparkBeyond engine. Please note that if several
                feature cuts are defined they will be evaluated during the model building by cross validation and
                may result in increased running time. Optional, 300 by default.
            automatic_selection_of_number_of_features (bool): A heuristic that aims to produce a one or more feature
                counts that will improve the cumulative RIG for the set of features. (All automatically produced cutoffs
                are guaranteed to be below the maximum limit defined in maxFeaturesCount). Please note that
                as several feature cuts can be produced and evaluated during the model building using cross validation,
                setting this feature to True may result in increased running time. Optional, False by default.
            min_support_absolute (int): Minimal support in absolute number of instances that any feature should have.
                Setting this parameter to a high value may result in less (than requested) features being produced.
                Optional, 3 by default.
            max_depth (float): A number < 8 which represent the maximum number of transformations allowed
                during the feature search phase. Increasing this value should be considered with cautious
                as the feature search phase is exponential. Optional, 2.5 by default.
            expanded_time_series (bool): A boolean indicator for whether to use depth of 3.5 for time window columns.
                True by default.
            feature_search_mode (string): Smart presets for creating deep features and explore interactions.
                See :obj:`.FeatureGeneration.FeatureSearchMode` for details.
            functions_white_list (:obj:`list` of str): A list of strings that represents a set of functions that
                will be used to guide the feature search. NA by default.
            functions_black_list (:obj:`list` of str): A list of strings that represents a set of function
                that will be excluded from the feature search. Can also include function domains including:
                'math','arithmetics', 'collections', 'booleanOperators', 'semantics', 'nlp', 'trigonometry', 'bitwise'.
                NA by default.
            local_top_feature_count (int): The maximal number of top features that should be created
                from a single column. 1000 by default.
            regression_discretizer_bins_override (:obj:`list` of float): Define the bin boundaries that should be
                created for regression problem bins. By default 6 bins will be created, with boundaries defined by equal
                mass (in order to not create a bias towards any of the bins). Should be a list of numbers spanning
                the entire target range. These bins will be used only for feature search purposes and not for
                model building.
            regression_number_of_bins (int): Explicitly specify the number of bins for equal mass discretization of
                the continuous target (ignored when :attr:`regression_discretizer_bins_override` is defined).
                6 by default.
            boolean_numeric_features (bool): A boolean indicating whether to transform all features to boolean values.
                (i.e., when False the continuous value of the feature left-hand-side will be passed to the algorithm,
                without taking into account the specific cutoff chosen during the feature search phase).
                By default True for classification problems and False for regression problems.
            numeric_equality_features (bool): A boolean indicator for whether to include features that compare
                numeric fields with specific values. True by default.
            equality_features (bool): A boolean indicator for whether to include features of the form form f(x) = y.
                True by default.
            allow_range_features: A boolean indicator for whether to include features that define range
                over a set of numeric values. True by default.
            auto_column_sub_sets (:obj:`list` of str): List of modes of column subsets generation.
                See :obj:`.FeatureGeneration.AutoColumnSubsets` for details. Default value is ["CONCEPT"]
            custom_column_subsets (:obj:`list` of list of str): A List of lists containing specific column subsets to
                examine. In order to set a certain depth to the subset, add an element in the end of the customSubSet
                with one digit as a string representing the requested depth. If not such element was defined
                the regular depth definitions will be used. NA by default.
            max_feature_duration (float): A numeric value representing the maximum allowed time a feature may take
                during search per row in milliseconds. 100 by default.
            override_max_feature_duration_for_external_data (bool): A boolean indicating whether
                the `max_feature_duration` parameter should not be used for features that use external data.
                True by default.
            allocated_memory_MB (int): Value representing how to chunk the memory during feature search. Optional.
            max_collection_size (int): Value representing what is the maximum cardinality allowed for a transformation
                during feature search. Optional, defaults to 200K.
            use_cached_features (bool): A boolean indicating whether to use cached features (from previous run).
                True by default.
            use_raw_numeric_columns (bool): Use the original numeric columns as features when building the model.
                This will automatically attempt to also build a model based only on the numeric columns with applying
                additional transformations on the data. True by default.
            gain_threshold (float): Remove features with information gain below the specified threshold.
                Default value is 0.001.
            time_vs_quality_factor (float): For large datasets, consider decreasing if a long feature search
                runtime is expected. Default value is 1/30
            time_vs_small_support_facto (float): For large datasets, consider increasing if many small support
                features are expected (e.g. in some text processing problems). May slow down feature search.
                Default value is 0.2.
            deduplication_similarity_threshold (float): Prune features by empirical similarity. Default value is 0.9.
            accelerated_feature_search (bool): Attempt to rule out hypotheses faster. This often reduces feature search
                time drastically without impacting discovery of insights or model performance. Default value is True.
    """

    class FeatureSearchMode:
        """Smart presets for creating deep features and explore interactions."""

        DEFAULT = "DEFAULT"
        """Standard feature search mode that composes all possible functions up to a predefined complexity \
        which is based on the column type, specific functions combination, and the depth definition."""

        AGGRESSIVE_WITH_PAIRS = "AGGRESSIVE_WITH_PAIRS"
        """The genetic algorithm will perform a quick exploration of many potential pairs."""

        ADVANCED = "ADVANCED"
        """This mode will attempt to create more composite functions combination in places \
        where a stronger signal was found - e.g., if an interim feature on time series data \
        has shown signal in preliminary analysis, more effort will be made to exact additional signal \
        by creating more complex expression which use or variant of that interim feature."""

        ADVANCED_WITH_PAIRS = "ADVANCED_WITH_PAIRS"
        """Similar to the `ADVANCED` with a focus on combining signals from pairs of interactions \
        and producing more complex features from promising interim features pairs - \
        please check "deep feature search with pairs example" in section G of the examples page."""
        # todo: example

        DIG_DEEP = "DIG_DEEP"
        """This mode would follow more aggressively at looking for interactions between multiple interim features, \
        and can attempt to create features using up to 5 fields. \
        Please check "deep feature search with many interactions" example in section G of the examples page."""
        # todo: example

    class AutoColumnSubsets:
        """Modes of column subsets generation"""

        CONCEPT = "CONCEPT"
        """Aim to generate column subset from fields that are from similar non-numeric types \
        or combination of date and non-numeric elements"""

        NUMERIC_PAIRS = "NUMERIC_PAIRS"
        """Create all column subsets for numeric columns"""

        ALL_PAIRS = "ALL_PAIRS"
        """Create subsets of size 2 from all columns"""

    def __init__(self,
                 max_features_count=None,
                 automatic_selection_of_number_of_features=None,
                 min_support_absolute=None,
                 max_depth=None,
                 expanded_time_series=None,
                 feature_search_mode=None,
                 functions_white_list=None,
                 functions_black_list=None,
                 local_top_feature_count=None,
                 regression_discretizer_bins_override=None,
                 regression_number_of_bins=None,
                 boolean_numeric_features=None,
                 numeric_equality_features=None,
                 equality_features=None,
                 allow_range_features=None,
                 auto_column_sub_sets=None,
                 custom_column_subsets=None,
                 max_feature_duration=None,
                 override_max_feature_duration_for_external_data=None,
                 allocated_memory_MB=None,
                 max_collection_size=None,
                 use_cached_features=None,
                 use_raw_numeric_columns=None,
                 gain_threshold=None,
                 time_vs_quality_factor=None,
                 time_vs_small_support_factor=None,
                 deduplication_similarity_threshold=None,
                 accelerated_feature_search=None):
        if max_features_count is None:
            self.maxFeaturesCount = None
        elif isinstance(max_features_count, int):
            self.maxFeaturesCount = [max_features_count]
        elif isinstance(max_features_count, (int, list, tuple)):
            self.maxFeaturesCount = max_features_count
        else:
            raise ValueError("max_features_count must be of type int or list[int], but was {0}", max_features_count)
        self.automaticSelectionOfNumberOfFeatures = automatic_selection_of_number_of_features
        self.minSupportAbsolute = min_support_absolute
        self.maxDepth = max_depth
        self.expandedTimeSeries = expanded_time_series
        self.featureSearchMode = feature_search_mode
        self.functionsWhiteList = functions_white_list
        self.functionsBlackList = functions_black_list
        self.localTopFeatureCount = local_top_feature_count
        self.regressionDiscretizerBinsOverride = regression_discretizer_bins_override
        self.regressionNumberOfBins = regression_number_of_bins
        self.booleanNumericFeatures = boolean_numeric_features
        self.numericEqualityFeatures = numeric_equality_features
        self.equalityFeatures = equality_features
        self.allowRangeFeatures = allow_range_features
        self.gainThreshold = gain_threshold
        self.timeVSQualityFactor = time_vs_quality_factor
        self.timeVSSmallSupportFactor = time_vs_small_support_factor
        self.deduplicationSimilarityThreshold = deduplication_similarity_threshold
        self.acceleratedFeatureSearch = accelerated_feature_search

        if auto_column_sub_sets is None:
            self.autoColumnSubSets = None
        elif not isinstance(auto_column_sub_sets, list):
            self.autoColumnSubSets = [auto_column_sub_sets]
        else:
            self.autoColumnSubSets = auto_column_sub_sets

        self.customColumnSubsets = custom_column_subsets
        self.maxFeatureDuration = max_feature_duration
        self.overrideMaxFeatureDurationForExternalData = override_max_feature_duration_for_external_data
        self.allocatedMemoryMB = allocated_memory_MB
        self.maxCollectionSize = max_collection_size
        self.useCachedFeatures = use_cached_features
        self.useRawNumericColumns = use_raw_numeric_columns


class AlgorithmDefinition:
    """Algorithm definition, including optional hyper params.

    Not meant to be instantiated directly, but using :class:`.Algorithms` helpers"""
    def __init__(self, name, **hyper_params):
        self.name = name
        self.hyper_params = hyper_params

    @staticmethod
    def _internal(name):
        def decorate(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                return AlgorithmDefinition(name, **kwargs)

            return wrapper

        return decorate


class Algorithms:
    """Algorithms definitions factory

    For convenience algorithms are grouped by platform.

    Examples:

        >>> Algorithms.scikit.decision_tree()
        >>> Algorithms.R.r_xg_boost()
    """
    class Weka:
        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.bayes.BayesianLogisticRegression')
        def bayesian_logistic_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.bayes.BayesNet')
        def bayes_net(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.bayes.NaiveBayes')
        def naive_bayes(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.LeastMedSq')
        def least_med_sq(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.LibLINEAR')
        def lib_linear(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.LibSVM')
        def lib_svm(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.LinearRegression')
        def linear_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.Logistic')
        def logistic(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.SMO')
        def smo(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.SMOreg')
        def smo_reg(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.functions.VotedPerceptron')
        def voted_perceptron(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.lazy.IBk')
        def ibk(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.AdaBoostM1')
        def ada_boost_m1(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.Bagging')
        def bagging(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.ClassificationViaClustering')
        def classification_via_clustering(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.ClassificationViaRegression')
        def classification_via_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.Decorate')
        def decorate(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.LogitBoost')
        def logit_boost(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.RandomSubSpace')
        def random_sub_space(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.meta.RegressionByDiscretization')
        def regression_by_discretization(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.rules.DecisionTable')
        def decision_table(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.trees.RandomForest')
        def random_forest(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.trees.REPTree')
        def rep_tree(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('weka.classifiers.trees.J48')
        def j48(**hyper_params): pass

    class scikit:
        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnAdaBoost')
        def ada_boost(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnBagging')
        def bagging(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnDecisionTree')
        def decision_tree(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnElasticNet')
        def elastic_net(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnElasticNetCVRegressor')
        def elastic_net_cv_regressor(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnGradientBoosting')
        def gradient_boosting(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLasso')
        def lasso(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLassoCV')
        def lasso_cv(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLassoLarsCV')
        def lasso_lars_cv(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLinearRegression')
        def linear_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLogisticRegressionClassifier')
        def logistic_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnLogisticRegressionCVClassifier')
        def logistic_regression_cv(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnNuSVMRegressor')
        def nu_svm(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnRandomForest')
        def random_forest(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnRidge')
        def ridge(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnSGD')
        def sgd(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnSVM')
        def svm(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SciKitLearnXGBoost')
        def xgboost(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('KerasDeepLearning')
        def keras_deep_learning(**hyper_params): pass

    class R:
        @staticmethod
        @AlgorithmDefinition._internal('RCaretGBM')
        def r_caret_gbm(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('RLassoGlmNet')
        def r_lasso_glm_net(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('RRandomForest')
        def r_random_forest(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('RRidgeGlmNet')
        def r_ridge_glm_net(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('RRpartDecisionTree')
        def r_rpart_decision_tree(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('RXGBoost')
        def r_xg_boost(**hyper_params): pass

    class MLlib:
        @staticmethod
        @AlgorithmDefinition._internal('MLlibDecisionTree')
        def mllib_decision_tree(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('MLlibGBTRegressor')
        def mllib_gbt_regressor(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('MLlibLinearModel')
        def mllib_linear_model(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('MLlibRandomForest')
        def mllib_random_forest(**hyper_params): pass

    @staticmethod
    @AlgorithmDefinition._internal('ZeroR')
    def zero_r(): pass

    class Ensembles:
        @staticmethod
        @AlgorithmDefinition._internal('BoundedStack(XGBoost,LinearRegression)')
        def ensembles_bounded_stack_xg_boost_linear_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('Stack(XGBoost,LinearRegression)')
        def ensembles_stack_xg_boost_linear_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('BoundedSortedStack(XGBoost,LinearRegression)')
        def ensembles_bounded_sorted_stack_xg_boost_linear_regression(**hyper_params): pass

        @staticmethod
        @AlgorithmDefinition._internal('SortedStack(XGBoost,LinearRegression)')
        def ensembles_sorted_stack_xg_boost_linear_regression(**hyper_params): pass


class EvaluationMetric:
    """Evaluation metric types"""

    AUC = "AUC"
    """The AUC is the area under the ROC curve, which is created by plotting the true positive rate against the false 
    positive rate at various threshold settings. The AUC measures the probability that a classifier will rank a positive
    instance as more likely than a negative instance. Used for classification problems."""
    RMSE = "RMSE"
    """Root Mean Square Error - calculates the difference between the predicted and actual for each observation, squares
     that difference, and then takes the average across all observations. RMSE gives a larger penalty to larger errors,
     so is useful when large errors need to be minimized. Used for regression."""
    PREC = "PREC"
    """Precision measures the probability that a positive prediction is actually true. It is the ratio between the
    number of true positives relative to all the positives identified by the model. Used for classification problems."""
    GINILIFT = "GINILIFT"
    """The Gini coefficient measures the purity of the resulting classes, or the expected chance of misclassification.
    Used for both regression and classification problems."""
    LOGLOSS = "LOGLOSS"
    """Log loss evaluates  a classifier based on its probability outputs instead of on discrete predictions. It takes
    into account the uncertainty of the prediction based on how much it varies from the actual label. Useful in
    classification cases where the actual prediction probabilities is important."""


class Knowledge:
    """External knowledge settings

        Args:
            linked_data_core (bool): includes DBPedia, Yago2, Wordnet and OpenLibrary.
                DBpedia is a crowd-sourced community effort to extract structured information from Wikipedia.
                Matches training data by Text elements. Defaults to False.
            open_street_map (bool): OpenStreetMap (OSM) is a collaborative project to create a free editable
                map of the world. Matches training data by location (coordinate). Defaults to False.
            weather (bool): Weather data from NOAA Climate.gov. Matches the training data by date and location.
                False by default.
            holidays (bool): National holidays for over 20 countries. Matches the training data by date and
                country/location. Defaults to False.
    """

    def __init__(self,
                 linked_data_core=None,
                 open_street_map=None,
                 weather=None,
                 holidays=None):
        self.linked_data_core = linked_data_core
        self.open_street_map = open_street_map
        self.weather = weather
        self.holidays = holidays


class ModelBuilding:
    """Model building settings

        Args:
            algorithms_white_list (:obj:`list` of :class:`.AlgorithmDefinition`): list of algorithms to run.
                See :obj:`.Algorithms`
            evaluation_metric (str): Model evaluation method, one of the options from :obj:`.EvaluationMetric`
            cross_validation (int): Number of cross-validation folds to use during the model-building phase,
                in order to select the best model and hyper-parameters.
                If left undefined, validation set will be used for model evaluation. If both crossValidation
                and validationSetRatio are defined, validation set will be used for model evaluation.
            validation_set_ratio (float): Ratio for validation set (out of the training data)
                to use during the model-building phase, in order to select the best model and hyper-parameters.
                Default value: 0.2. If both crossValidation and validationSetRatio are defined,
                validation set will be used for model evaluation.
            max_records_for_model_build (int): Max records number used for building the model
    """

    def __init__(self,
                 algorithms_white_list=None,
                 # extra_models=None,
                 evaluation_metric=None,
                 cross_validation=None,
                 validation_set_ratio=None,
                 max_records_for_model_build=None):
        self.algorithmsWhiteList = algorithms_white_list
        self.evaluationMetric = evaluation_metric
        self.crossValidation = cross_validation
        self.validationSetRatio = validation_set_ratio
        self.maxRecordsForModelBuild = max_records_for_model_build


class Reporting:
    """Reporting settings

        Args:
            show_web_view (bool): An indicator for whether to show a dynamic web view of the analysis in
                a browser. True by default.
            email_for_notification (str): An optional email to notify when the learning is finished.
            score_on_test_set (bool): An indicator for whether scoring should be provided for the test set.
                False by default.
            feature_clusters_report (bool): Produce feature cluster visualization. False by default.
            evaluated_functions_report (bool): Create a report with the entire list of functions that were evaluated.
                For contexTs will also show for each context which functions directly used it.
    """
    def __init__(self,
                 show_web_view=True,
                 email_for_notification=None,
                 score_on_test_set=None,
                 feature_clusters_report=None,
                 evaluated_functions_report=None):
        self.showWebView = show_web_view
        self.emailForNotification = email_for_notification
        self.scoreOnTestSet = score_on_test_set
        self.featureClustersReport = feature_clusters_report
        self.evaluatedFunctionsReport = evaluated_functions_report


class DataInput:
    """
        Base class for DataFrame like inputs.
        Used as data source for train/test predict/enrich data sets, as well as DataFrame based contexts.
    """
    def __init__(self):
        pass


class DataFrameInput(DataInput):
    """DataFrame input, includes DataFrame and additional params.

        Args:
            data_frame (:obj:`pandas.DataFrame`): pandas DataFrame to export to server.
            name (str): named identifier for this input. Subsequent usage of input with the same name will override
                previously uploaded data.
    """
    def __init__(self, data_frame, name):
        DataInput.__init__(self)
        self.data_frame = data_frame
        self.name = name


class DataFileInput(DataInput):
    """File input, defines a file and the parameters that are used to load it as :obj:`pandas.DataFrame`

        Args:
            file_path (str): local path to the data file.
            name (str): named identifier for this input. Subsequent usage of input with the same name will override
                previously uploaded data. Optional, defaults to the name of the file.
            encoding (str): file encoding. Optional, if undefined, the server will discover the encoding automatically.
            is_quoted (bool): A boolean indicating whether the data is quoted. Optional, defaults to True.
            use_escaping (bool): A boolean indicating whether to treat '\\' as escaping character.
                Optional, defaults to False.
            empty_value_policy (:obj:`.EmptyValuePolicy`): defines how empty values are treated.
                Optional, defaults to `EmptyValuePolicy.DoubleNaN`.
    """
    def __init__(self, file_path, name=None, encoding=None, is_quoted=None, use_escaping=None, empty_value_policy=None):
        DataInput.__init__(self)
        self.file_path = file_path
        self.name = name
        self.encoding = encoding
        self.is_quoted = is_quoted
        self.use_escaping = use_escaping
        self.empty_value_policy = empty_value_policy


class WebFileInput(DataInput):
    """Web File input, includes DataFrame and additional params.

        Args:
            url (str): url to a dataset file.
            name (str): named identifier for this input.
    """
    def __init__(self, url, name):
        DataInput.__init__(self)
        self.url = url
        self.name = name

    def __repr__(self):
        return "WebFile(url={}, name={})".format(self.url, self.name)


class _Context:
    """Context definition.

        Not meant to be instantiated directly, but using :class:`.Contexts` helpers"""

    def __init__(self, name):
        self.name = name


class _DataContext(_Context):
    """Context object based on DataFrame

        Args:
            data (:class:`pandas.DataFrame` or :class:`.DataInput`): a data frame or :class:`.DataInput` object \
            describing the data source
            name (string): an identifier for the context object to be created
            context_types (list(string)): one of the context types available under :class:`Contexts._ContextType`
            partition_by (str): partition the context data frame into many parts.
            max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
            **params: additional params, needed for certain context types:

                key_columns (list(string)): Specifies the key columns for LOOKUP_TABLES and TIME_SERIES_MAP and CATEGORICAL_ENCODING contexts
                time_column (string): Specifies the time column for TIME_SERIES and TIME_SERIES_MAP contexts
                graph_source_node_column (string): Specifies the graph source node column for GRAPH context
                graph_target_node_column (string): Specifies the graph target node column for GRAPH context
                smoothing_coefficient (float): Taking only positive values, larger values can be used to mitigate overfitting for CATEGORICAL_ENCODING context
                as_discrete (bool): In some cases it may be necessary to force a numeric target as discrete for CATEGORICAL_ENCODING context
                max_rows (int): A sample of maxRows will be used for context generation, supported by CATEGORICAL_ENCODING context
                max_cardinality_threshold (float): The maximum cardinality threshold can be used to mitigate overfitting, supported by CATEGORICAL_ENCODING context
                target_column (string): Specifies the target column for CATEGORICAL_ENCODING context
    """

    def __init__(self, data, name, context_types=None, partition_by=None, max_partitions=None, **params):
        _Context.__init__(self, name)
        if context_types is None:
            context_types = []
        self.data = data
        self.context_types = context_types
        self.partition_by = partition_by
        self.max_partitions = max_partitions
        self.additional_params = params


class Contexts:
    """Contexts definitions factory

        Examples:
            >>> import sparkbeyond
            >>> Contexts.LookupTableContext(data=sparkbeyond.examples.datasets.sentiment_lexicon(),
                                            name="sentiment_lexicon",
                                            key_column="Words")
    """

    class _ContextType:
        """Available context types"""

        GEO_SPATIAL = "GeoSpatial"
        GRAPH = "Graph"
        TEXT_INDEX = "TextIndex"
        LOOKUP_TABLES = "LookupTables"
        CATEGORICAL_ENCODING = "CategoricalEncoding"
        MEMBERSHIP_SET = "MembershipSet"
        OSM_FILE = "OSMFile"
        SHAPE_FILE = "SpatialIndexFromShapes"
        TIME_SERIES = "TimeSeries"
        TIME_SERIES_MAP = "TimeSeriesMap"
        WORD_2_VEC = "Word2Vec"
        WORD_2_VEC_PRETRAINED_S3 = "Word2VecPretrainedS3"
        WORD_2_VEC_PRETRAINED_LOCAL = "Word2VecPretrainedLocal"

    class GeoSpatialContext(_DataContext):
        """This context allows looking for geo spatial features.

            All rows are indexed based on their coordinate information, allowing properties from the surrounding
            environment to be searched for in a KNN-fashion. A coordinate column is required for this context object
            to be created.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                time_column (str): defines the time column in context data.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, time_column=None, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data=data,
                                  name=name,
                                  time_column=time_column,
                                  context_types=[Contexts._ContextType.GEO_SPATIAL],
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class TextIndexContext(_DataContext):
        """This context creates an text index out of text column provided in a context.

            The properties of each text can be search for in a KNN-fashion. A text column is required for
            this context object.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                text_column (str): name of the column containing the text.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, text_column, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data=data,
                                  name=name,
                                  context_types=[Contexts._ContextType.TEXT_INDEX],
                                  key_columns=[text_column],
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class LookupTableContext(_DataContext):
        """This context creates a lookup table for each key column using all other columns as properties that can be
            associated with the key.

            The key column should be unique and can be defined in the keyColumns parameter.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                key_columns (:obj:`list` of str): key column names.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, key_columns=(), partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data=data,
                                  name=name,
                                  context_types=[Contexts._ContextType.LOOKUP_TABLES],
                                  key_columns=key_columns,
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class CategoricalEncodingContext(_DataContext):
        """This context creates categorical likelihood encodings for each categorical column in the context using
            the specified key column as the encoding. It is never advised to include test data in this context.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                target_column (str): The name of the column to be used to encode categorical columns.
                    This is usually the training target column. If not specified, a column name matching
                    the training target name will be used.
                key_columns (:obj:`list` of str): The category columns.
                    These columns will be used as lookups during learning.
                smoothing_coefficient (float): Taking only positive values,
                    larger values can be used to mitigate overfitting. Default: 3.0.
                as_discrete (bool): Under some scenarios it may be desirable to encode a numeric target/key as discrete.
                max_rows (int): A sample of maxRows will be used to encode categorical columns. Default: 100,000.
                max_cardinality_threshold (float): The maximum cardinality threshold can be used to mitigate overfitting.
                    Expressed as a percentage of the number of context rows. For example 0.8 will require that the
                    context object column cardinality be less than 80% of the context data frame size. Default: 0.5.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, target_column=None, key_columns=(), smoothing_coefficient=None, as_discrete=None, max_rows=None, max_cardinality_threshold=None, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data=data,
                                  name=name,
                                  context_types=[Contexts._ContextType.CATEGORICAL_ENCODING],
                                  key_columns=key_columns,
                                  target_column=target_column,
                                  smoothing_coefficient=smoothing_coefficient,
                                  as_discrete=as_discrete,
                                  max_rows=max_rows,
                                  max_cardinality_threshold=max_cardinality_threshold,
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class TimeSeries(_DataContext):
        """This context creates a single time series per column for all the rows provided.

            This context requires at least one time window to be defined in :obj:`.ProblemDefinition`.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                time_column (str): defines the time column in context data.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, time_column=None, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data,
                                  name,
                                  context_types=[Contexts._ContextType.TIME_SERIES],
                                  time_column=time_column,
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class TimeSeriesMap(_DataContext):
        """This context creates multiple time series per column, grouped by a key.

            This context requires at least one time window to be defined in :obj:`.ProblemDefinition`.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                key_column (str): defines the key column in context data.
                time_column (str): defines the time column in context data.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, key_column, time_column, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data,
                                  name,
                                  key_columns=[key_column],
                                  context_types=[Contexts._ContextType.TIME_SERIES_MAP],
                                  time_column=time_column,
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class GraphContext(_DataContext):
        """This context allows looking for features on a graph or a network.

            This context requires defining the edges in the graph by setting the source column and target column.

            Args:
                data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): data frame containing the context data.
                name (str): an identifier for the context object to be created. Context names should be unique.
                source_node_column (str): source node column.
                target_node_column (str): target node column.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, data, name, source_node_column, target_node_column, partition_by=None, max_partitions=None):
            _DataContext.__init__(self,
                                  data,
                                  name,
                                  context_types=[Contexts._ContextType.GRAPH],
                                  graph_source_node_column=source_node_column,
                                  graph_target_node_column=target_node_column,
                                  partition_by=partition_by,
                                  max_partitions=max_partitions)

    class OsmFileContext(_Context):
        """This context allows using Open Street Map files

            Args:
                file_path (str): a path to OSM file.
                name (str): an identifier for the context object to be created. Context names should be unique.
        """

        def __init__(self, file_path, name):
            _Context.__init__(self, name)
            self.file_path = file_path
            self.context_type = Contexts._ContextType.OSM_FILE

    class ShapeFileContext(_Context):
        """This context allows using Shape files

            Args:
                file_path (str): a path to Shape file, should point to a <FILE_NAME>.shp file.
                    Additionally at least 2 files should be present in the same directory: <FILE_NAME>.shx,
                    <FILE_NAME>.dbf.
                name (str): an identifier for the context object to be created. Context names should be unique.
                partition_by (str): partition the context data frame into many parts.
                max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
        """

        def __init__(self, file_path, name, partition_by=None, max_partitions=None):
            _Context.__init__(self, name)
            self.file_path = file_path
            self.context_type = Contexts._ContextType.SHAPE_FILE
            self.partition_by = partition_by
            self.max_partitions = max_partitions

    class CodeFileContext(_Context):
        """This context allows providing a file containing additional functions

            Args:
                url (str): url to file location.
        """

        def __init__(self, url):
            _Context.__init__(self, "Code file")
            self.url = url

    class FeaturesFromRevisionContext(_Context):
        """This context allows reusing features discovered in a previous revision

           Args:
               revision (int): revision number.
               name (str): an identifier for the context object to be created. Context names should be unique.
       """

        def __init__(self, revision, name):
            _Context.__init__(self, name)
            self.revision = revision

    class Word2Vec:
        """Word2vec can be used in several ways, using prebuilt models and training a word2vec model based on data. \
            For more details see: :obj:`.Contexts.Word2Vec.TrainOnData`, :obj:`.Contexts.Word2Vec.PretrainedS3`, \
            :obj:`.Contexts.Word2Vec.PretrainedLocal`
        """

        class TrainOnData(_DataContext):
            """This context allows to train a word2vec model on the supplied data

                Args:
                    name (str): an identifier for the context object to be created. Context names should be unique.
                    data (:obj:`pandas.DataFrame` or :obj:`.DataInput`): dataframe based on which a word2vec model
                        will be created.
                    key_columns (:obj:`list` of str): names of columns to be used for building word2Vec model.
                    partition_by (str): partition the context data frame into many parts.
                    max_partitions (int): maximum number of partitions to be used, if ``partition_by`` is specified.
            """

            def __init__(self, data, name, key_columns, max_partitions=None, partition_by=None):
                _DataContext.__init__(self,
                                      data=data,
                                      name=name,
                                      context_types=[Contexts._ContextType.WORD_2_VEC],
                                      key_columns=key_columns,
                                      partition_by=partition_by,
                                      max_partitions=max_partitions)

        class PretrainedS3(_Context):
            """This context allows to use one of the available word2vec models

                Args:
                    name (str): an identifier for the context object to be created. Context names should be unique.
                    model_name (str): name of one of the pretrained models.
                        Available models: "Wikipedia", "Wikipedia-Gigaword", "CommonCrawl", "Twitter", "GoogleNews"
            """
            def __init__(self, name, model_name="Wikipedia"):
                _Context.__init__(self, name)
                self.model_name = model_name
                self.context_types = [Contexts._ContextType.WORD_2_VEC_PRETRAINED_S3]

        class PretrainedLocal(_DataContext):
            """This context allows using a pretrained Word2Vec model supplied by user

                Args:
                    data (:obj:`pandas.DataFrame`): a data frame which contains text column followed by Word2Vec vector
                        columns.
                    name (str): an identifier for the context object to be created. Context names should be unique.
            """
            def __init__(self, data, name):
                _DataContext.__init__(self,
                                      data=data,
                                      name=name,
                                      context_types=[Contexts._ContextType.WORD_2_VEC_PRETRAINED_LOCAL])


class EvaluationResult:
    """Learning session evaluation results

        Args:
            evaluation_method (str): AUC/PREC/RMSE
            score (float): model score
            summary (str): text summary of the model score
            details (dict): additional evaluation details
    """

    def __init__(self, evaluation_method, score, summary, details):
        self.evaluation_method = evaluation_method
        self.score = score
        self.summary = summary
        self.details = details


class ModelExports:
    """ Model export downloads """
    FEATURE_EXTRACTOR = "Feature Extractor"
    MODEL = "Model"
    CONTEXTS = "Contexts"


class LearningDefinition:
    def __init__(self, inputs_schema):
        self.inputs_schema=inputs_schema

    def print_inputs_schema(self):
        import os

        def format_input_structure(input_structure):
            column_types = {column_name: column_meta_data['type']
                            for column_name, column_meta_data in input_structure.items()}

            if column_types is not None and len(column_types) > 0:
                width_col1 = max(max([len(x) for x in column_types.keys()]), 6)
                width_col2 = max(max([len(x) for x in column_types.values()]), 4)
                total_width = width_col1 + width_col2 + 7

                header = " {2} \n| {0:<{col1}} | {1:<{col2}} |\n|{2}|" \
                    .format('column', 'type', '-' * (total_width - 2), col1=width_col1, col2=width_col2)
                footer = ' ' + '-' * (total_width - 2) + ' '
                body = os.linesep.join(
                    ["| {0:<{col1}} | {1:<{col2}} |"
                         .format(column_name, type, col1=width_col1, col2=width_col2)
                     for column_name, type in column_types.items()])
                return os.linesep.join([header, body, footer])
            else:
                return None

        log.info("Inputs schema:")
        for name, schema in self.inputs_schema.items():
            log.info("{}:\n{}\n".format(name, format_input_structure(schema)))
