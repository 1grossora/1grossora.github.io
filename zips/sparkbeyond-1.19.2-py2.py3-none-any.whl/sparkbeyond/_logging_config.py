import logging
import sys


# Enabling debugging at http.client level (requests->urllib3->http.client)
# you will see the REQUEST, including HEADERS and DATA, and RESPONSE with HEADERS but without DATA.
# the only thing missing will be the response.body which is not logged.
try:  # for Python 3
    from http.client import HTTPConnection
except ImportError:
    from httplib import HTTPConnection
# HTTPConnection.debuglevel = 1

# logging init
logging.basicConfig()


# loggers
_SPARKBEYOND_LOGGER = logging.getLogger("sparkbeyond")
_REQUESTS_LOG = logging.getLogger("requests.packages.urllib3")


# Formats
_MESSAGE_ONLY_FORMAT = '%(message)s'
_DETAILED_FORMAT = '%(asctime)s %(levelname)s:%(message)s'


# Output handler
_OUT_HANDLER = logging.StreamHandler(sys.stdout)
_OUT_HANDLER.setLevel(level=logging.INFO)
_OUT_HANDLER.setFormatter(logging.Formatter(_MESSAGE_ONLY_FORMAT))

_SPARKBEYOND_LOGGER.addHandler(_OUT_HANDLER)
_SPARKBEYOND_LOGGER.propagate = False
_REQUESTS_LOG.addHandler(_OUT_HANDLER)
_REQUESTS_LOG.propagate = False


def _configure_console_logging(level):
    _SPARKBEYOND_LOGGER.debug("Logging level set to %s", level)
    _OUT_HANDLER.setLevel(level)
    _SPARKBEYOND_LOGGER.setLevel(level)
    if level >= logging.INFO:
        _REQUESTS_LOG.setLevel(level if level > logging.INFO else logging.WARNING)
        _OUT_HANDLER.setFormatter(logging.Formatter(_MESSAGE_ONLY_FORMAT))
        HTTPConnection.debuglevel = 0
    else:
        _OUT_HANDLER.setFormatter(logging.Formatter(_DETAILED_FORMAT))
        HTTPConnection.debuglevel = 1


def verbose(enable=True):
    _configure_console_logging(logging.DEBUG) if enable else _configure_console_logging(logging.INFO)


verbose(False)
