import logging
import time
import sys
from pandas import read_csv
from ._internal_api import OperationFailure
from ._internal_api.api_dtos import EnrichPredictJobState
from . import _type_error_report

log = logging.getLogger(__name__)


class EnrichmentJob:
    """A handler for monitoring, canceling or getting the result of the enrichment job

        Args:
            job_id (str): enrichment job id
    """

    def __init__(self, user_session, job_id, total_rows=None):
        self.user_session = user_session
        self.job_id = job_id
        self.total_rows = total_rows
        self.data = None

    def _print_state(self, state):
        """Print the state to system out

            Args:
                state (EnrichPredictJobState): job state.
        """
        if state.is_enqueued():
            log.info('Enrichment job is waiting in queue')
        elif state.is_running():
            if state.status.built_contexts is False:
                log.info("Enrichment job is running. Parsing contexts...")
            else:

                total_rows_message = "out of {0} ".format(self.total_rows) if self.total_rows is not None else ""
                sys.stdout.write("\rEnrichment job is running. So far processed {0} {1}rows"
                                 .format(state.status.processed_rows,
                                         total_rows_message))
                sys.stdout.flush()
        elif state.is_completed():
            def _timestamp_to_string(timestamp):
                import datetime
                return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

            if state.result.is_succeeded():
                log.info(_type_error_report.print_type_error_overview(state.status.typer_errors_report))

                total_rows_message = "out of {0} ".format(self.total_rows) if self.total_rows is not None else ""
                log.info("\nEnrichment has finished successfully. Processed %s %s rows. Started: %s. Ended: %s",
                         state.status.processed_rows, total_rows_message,
                         _timestamp_to_string(state.started_millis), _timestamp_to_string(state.ended_millis))
            else:
                log.error("\nEnrichment failed: %s. Worker ID: %s. Started: %s. Ended: %s.",
                          state.result.error, state.worker_id,
                          _timestamp_to_string(state.started_millis), _timestamp_to_string(state.ended_millis)),
        else:
            log.error("Unexpected job state:", state)

    def current_status(self):
        """Get enrichment job status - Started/Finished, number of lines processed, etc."""
        state = self.user_session.get_enrich_predict_job_state(self.job_id)
        self._print_state(state)

    def get_data(self, local_file_name=None, run_blocking=True):
        """Get enrichment result

        Args:
            local_file_name (str): local file name for saving the result
            run_blocking (bool): if True block until the result is ready, otherwise return the data (or None if data
                is not currently available) immediately

        Returns:
            :obj:`pandas.DataFrame`: If `run_blocking` is True, block until the job finishes while showing \
                processed rows counter, and return the result when available. If `run_blocking` is False \
                return the data if available, else return None
        """

        output_name = local_file_name if local_file_name is not None else "enriched-" + self.job_id

        if self.data is not None:
            return self.data
        elif run_blocking:
            time.sleep(1)
            state = self.user_session.get_enrich_predict_job_state(self.job_id)
            if not state.is_completed():
                log.info("Blocking until enrichment result is available.")

            while not state.is_completed():
                time.sleep(5)
                state = self.user_session.get_enrich_predict_job_state(self.job_id)
                self._print_state(state)

            if state.result.is_succeeded():
                try:
                    local_path = self.user_session.download_job_result(self.job_id, output_name + ".tsv.gz")
                    self.data = read_csv(local_path, sep='\t', index_col=None)
                    return self.data
                except OperationFailure as e:
                    raise OperationFailure("Failed to download enrichment result: {0}".format(e.message))
            else:
                raise OperationFailure("Enrichment failed: {0}".format(state.result.error))

        else:
            log.info("Data isn't available locally. Use run_blocking=TRUE to get the data when enrichment result \
                is ready")
            return None

    def job_reports(self):
        """Show interactive list of the available enrichment job reports -
        enter a report number to browse to the report."""
        state = self.user_session.get_enrich_predict_job_state(self.job_id)
        report_files_list = state.result.success['reportFilenames'] \
            if state.result.success['reportFilenames'] is not None else []

        report_files_list = [i for i in report_files_list if i != 'typerErrorsReport.json']

        report_files = dict(enumerate(report_files_list, start=1))

        for num, name in report_files.items():
            print("[{0}] {1}".format(num, name))
        choice = raw_input('Enter a number of report to show or <enter> otherwise: ')
        try:
            report_name = report_files[int(choice.strip())]
            log.info("Showing %s", report_name)
            self.user_session.show_prediction_report(self.job_id, report_name)
        except Exception as e:
            print("Invalid input, should be a number between 1 and {}".format(report_files.__len__()))

    def cancel(self):
        """Cancel the job"""
        self.user_session.cancel_job(self.job_id)
