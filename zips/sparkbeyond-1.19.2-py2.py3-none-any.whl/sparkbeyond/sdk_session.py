from . import _internal_api as server_api
from .sdk_dtos import *
from . import _sdk_actions
from .learning_session import LearningSession
from ._sdk_actions import LearningJobStatus
from .environments import EnvironmentRepository
import logging

log = logging.getLogger(__name__)


class SdkSession:
    """SDK User Session.

        Lets the user start a learning session or load the previously executed learning session for analysis

        Args:
            server_url (str): the server (default `http://localhost:9000`)
            username (str): the username for the discovery platform (default None)
            password (str): the password for the discovery platform (default None)
            safe_ssl (bool): use safe SSL, to be set to false only for local servers (default True)

    """
    def __init__(self, server_url='http://localhost:9000', username=None, password=None, safe_ssl=True):
        self._server_api_session = server_api.UserSession(server_url, username, password, safe_ssl)
        try:
            self._world_knowledge = _sdk_actions.update_world_knowledge_objects(
                self._server_api_session)
        except Exception as e:
            log.warn('Failed to get world knowledge metadata - world knowledge will be disabled. \n{}'
                        .format(str(e)))
            self._world_knowledge = None


    def learn(self,
              project_name,
              train_data,
              target,
              test_data=None,
              context_datasets=None,
              knowledge=Knowledge(),
              pre_processing=PreProcessing(),
              feature_generation=FeatureGeneration(),
              problem_definition=ProblemDefinition(),
              model_building=ModelBuilding(),
              reporting=Reporting(),
              run_blocking=True,
              revision_description=None,
              learning_mode=None,
              parent_revision=None):
        """Start a new learning process

            Args:
                project_name (string): project name
                train_data (pandas.DataFrame or :class:`.DataInput`): train data to analyze
                target (string): target column name
                test_data (pandas.DataFrame or :class:`.DataInput`): test data to validate model results
                context_datasets (list(Context)): A list of contexts to be used in learning. Use helper functions
                    from :class:`.Contexts` class to define the contexts
                knowledge (:class:`.Knowledge`): external knowledge params
                pre_processing (:class:`.PreProcessing`): data preprocessing params
                feature_generation (:class:`.FeatureGeneration`): feature generation params
                problem_definition (:class:`.ProblemDefinition`): problem definition
                model_building (:class:`.ModelBuilding`): model building params
                reporting (:class:`.Reporting`): reporting settings
                run_blocking (bool): wait for learning to finish
                revision_description (string): string revision comment
                learning_mode (string): Select default settings consistent with a given learning strategy:
                    Insight, OptimizeModel. Defaults to None.
                    Insight Mode: Fast learning iterations with an emphasis on qualitative feature discovery.
                    Features will convey insights into the problem while avoiding extended learning sessions intended
                    to maximize predictive performance.
                    OptimizeModel Mode: Predictive performance is paramount. This mode aims to provide a starting point for
                    achieving strong predictive performance. The features may be less human friendly as they attempt to
                    maximize signal extracted from the data. Runtime may be longer as larger and more models are built
                    in the pursuit of performance.
                parent_revision (int) : parent revision for this learning. Set parent_revision = sparkbeyond.ProjectRevision.ROOT to put this revision under root. If no parent revision is specified, the server will find the most suitable.

            Returns (:class:`.LearningSession`):
        """
        learning_job = _sdk_actions.learn(self._server_api_session,
                                          project_name,
                                          train_data,
                                          target,
                                          test_data,
                                          context_datasets,
                                          knowledge,
                                          pre_processing,
                                          feature_generation,
                                          problem_definition,
                                          model_building,
                                          reporting,
                                          revision_description=revision_description,
                                          learning_mode=learning_mode,
                                          parent_revision=parent_revision)

        if parent_revision and self._server_api_session.is_server_version_older_than("1.18"):
            log.warn("parent_revision is supported from version 1.18")

        if run_blocking:
            log.info("You are now running in a Blocking Mode")
            job_status = _sdk_actions.wait_for_learn_job_to_finish(
                                                                    self._server_api_session,
                                                                    learning_job.project_name,
                                                                    learning_job.revision,
                                                                    learning_job.job_id)
            if (job_status.status == LearningJobStatus.Statuses.FAILED):
                log.error("Learning failed with error: %s", job_status.error)

        return LearningSession(user_session=self._server_api_session,
                               project_name=learning_job.project_name,
                               revision=learning_job.revision,
                               job_id=learning_job.job_id)

    def review(self, project_name, revision, job_id=None):
        """ Review a previously executed learning process

            Args:
                project_name (string): project name
                revision (int): learning revision
                job_id (int): running learning session identifier, if available

            Returns (:class:`.LearningSession`):
        """
        return LearningSession(user_session=self._server_api_session,
                               project_name=project_name,
                               revision=revision,
                               job_id=job_id)

    def environments(self):
        """ Environment Management Repository.

            Returns: (:class:`.environments.EnvironmentRepository`):
        """
        return EnvironmentRepository(self._server_api_session)

    @property
    def world_knowledge(self):
        """ World knowledge.
            see :mod:`.world_knowledge` for more details
        """
        return self._world_knowledge
