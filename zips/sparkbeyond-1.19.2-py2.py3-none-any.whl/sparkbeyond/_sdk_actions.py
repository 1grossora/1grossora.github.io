import os
from .sdk_dtos import *
from .sdk_dtos import AlgorithmDefinition
from . import _type_error_report
from . import world_knowledge
from ._internal_api import *
from ._upload_helper import upload_data_frame_to_server as upload_data_frame
from ._upload_helper import upload_data_file_to_server as upload_data_file
from ._upload_helper import upload_file_to_server
from ._utils import validation
from pandas import DataFrame
import logging

log = logging.getLogger(__name__)


def _wrap_with_data_input_if_needed(data, name="Dataset"):
    validation.assert_one_of_types(data, (DataFrame, DataInput))
    return data if isinstance(data, DataInput) else DataFrameInput(data, name)


def _dict_filter_none_values(d):
    validation.assert_type(d, dict)
    dict((k, v) for k, v in d.items() if v)


def _handle_data(project_name, user_session, data, pre_processing=PreProcessing()):
    """Create a data reference based on remote resource reference.
           remote_resource: FileReference
       Returns:
           data_provider - The data provider that represent the input
   """
    validation.assert_type(data, DataInput)

    def data_frame_input_from_remote_file_resource(remote_resource, preprocessing=PreProcessing(), name = None):
        return DataFrameInputs.local_file(
                                        name=name if name else remote_resource.path,
                                        file_reference=remote_resource,
                                        encoding=preprocessing.fileEncoding,
                                        use_escaping=preprocessing.fileEscaping,
                                        empty_value_policy=preprocessing.emptyValuePolicy)

    if isinstance(data, DataFrameInput):
        remote_file_resource = upload_data_frame(project_name, user_session, data)
        return data_frame_input_from_remote_file_resource(remote_file_resource, pre_processing, data.name)
    elif isinstance(data, DataFileInput):
        remote_file_resource = upload_data_file(project_name, user_session, data)
        return data_frame_input_from_remote_file_resource(remote_file_resource, pre_processing)
    elif isinstance(data, WebFileInput):
        return DataFrameInputs.web_file(name=data.name, url=data.url)
    else:
        raise ValueError("Data input type is not supported: %s", type(data))


def _handle_context(project_name, user_session, context, pre_processing=PreProcessing()):
    """Transform context to ContextDatasetWrapper and upload data if needed"""
    from .sdk_dtos import _Context, _DataContext

    validation.assert_one_of_types(context, [_Context, world_knowledge.WorldKnowledgeObject])

    if isinstance(context, world_knowledge.WorldKnowledgeObject):
        # WorldKnowledgeObject contains settings of both data source and context, so a context can be constructed
        # based on it. If WorldKnowledgeObject is passed as a context, convert it to context definition.
        context = context._as_context
    elif isinstance(context, _DataContext) and isinstance(context.data, world_knowledge.WorldKnowledgeObject):
        # WorldKnowledgeObject can be passed as a data input for any context and then it's up to the user to specify
        # the rest of context's params
        context.data = context.data._as_data_input

    if isinstance(context, _DataContext):
        context.data = _wrap_with_data_input_if_needed(context.data, context.name if context.name else "Context")
        context_provider = _handle_data(project_name, user_session, context.data, pre_processing)

        key_columns = context.additional_params.get("key_columns")
        time_column = context.additional_params.get("time_column")
        graph_source_node_column = context.additional_params.get("graph_source_node_column")
        graph_target_node_column = context.additional_params.get("graph_target_node_column")
        smoothing_coefficient = context.additional_params.get("smoothing_coefficient")
        as_discrete = context.additional_params.get("as_discrete")
        max_rows = context.additional_params.get("max_rows")
        max_cardinality_threshold = context.additional_params.get("max_cardinality_threshold")
        target_column = context.additional_params.get("target_column")

        return ContextDatasetWrapper(contextProvider=context_provider,
                                     name=context.name,
                                     keyColumns=validation.wrap_with_list_if_needed(key_columns),
                                     timeColumn=time_column,
                                     graphSourceNodeColumn=graph_source_node_column,
                                     graphTargetNodeColumn=graph_target_node_column,
                                     partitionBy=context.partition_by,
                                     maxPartitions=context.max_partitions,
                                     smoothingCoefficient=smoothing_coefficient,
                                     asDiscrete=as_discrete,
                                     maxRows=max_rows,
                                     maxCardinalityThreshold=max_cardinality_threshold,
                                     targetColumn=target_column,
                                     contextTypes=context.context_types)
    elif isinstance(context, Contexts.CodeFileContext):
        return ContextDatasetWrapper(contextProvider=dict(jsonClass="com.sparkbeyond.runtime.data.transform.CodeFile",
                                                          name="Code file",
                                                          url=context.url))
    elif isinstance(context, Contexts.OsmFileContext):
        server_side_data_resource = upload_file_to_server(session=user_session,
                                                          local_path=context.file_path,
                                                          project_name=project_name)
        return ContextDatasetWrapper(
            contextProvider=DataFrameInputs.osm_file(context.name, server_side_data_resource),
            name=context.name,
            contextTypes=[context.context_type]
        )
    elif isinstance(context, Contexts.ShapeFileContext):
        def find_files_related_to_shape_file(shape_file_path):
            validation.assert_file_exists(shape_file_path)
            shape_file_name, shape_file_extension = os.path.splitext(shape_file_path)
            if shape_file_extension != ".shp":
                raise ValueError("file_path in ShapeFileContext should point to a file with .shp extension. "
                                 "Instead received: {0}".format(shape_file_path))

            related_extensions = [".dbf", ".shx", ".cpg", ".prj"]
            related_files = [shape_file_name + ext for ext in related_extensions
                             if os.path.exists(shape_file_name + ext)]

            required_extensions = [".dbf", ".shx"]
            required_files = [shape_file_name + ext for ext in required_extensions]

            if set(required_files).issubset(set(related_files)):
                return related_files
            else:
                raise ValueError("Missing some  mandatory files for shape file: {0}.\n Required: {1}.\n Found: {2}"
                                 .format(shape_file_path, required_files, related_files))

        [upload_file_to_server(session=user_session, local_path=f, project_name=project_name)
         for f in find_files_related_to_shape_file(context.file_path)]

        server_side_data_resource = upload_file_to_server(session=user_session,
                                                          local_path=context.file_path,
                                                          project_name=project_name)
        return ContextDatasetWrapper(
            contextProvider=DataFrameInputs.shape_file(context.name, server_side_data_resource),
            name=context.name,
            contextTypes=[context.context_type],
            partitionBy=context.partition_by,
            maxPartitions=context.max_partitions
        )
    elif isinstance(context, Contexts.FeaturesFromRevisionContext):
        return ContextDatasetWrapper(
            contextProvider=DataFrameInputs.features_from_revision(name=context.name, revision=context.revision),
            name=context.name
        )
    elif isinstance(context, Contexts.Word2Vec.PretrainedS3):
        return ContextDatasetWrapper(
            contextProvider=DataFrameInputs.word_2_vec(name=context.name, source=context.model_name),
            name=context.name,
            contextTypes=context.context_types
        )


def _to_hyper_params_settings(algorithms_with_hyper_params):
    hyper_params_executions = [(alg.name, alg.hyper_params) for alg in algorithms_with_hyper_params]
    hyper_params_settings = {}
    for alg_name, params in hyper_params_executions:
        if alg_name not in hyper_params_settings:
            hyper_params_settings[alg_name] = []
        hyper_params_settings[alg_name].append(params)

    return hyper_params_settings


def learn(user_session,
          project_name,
          train_data,
          target,
          test_data=None,
          context_datasets=(),
          knowledge=Knowledge(),
          preProcessing=PreProcessing(),
          featureGeneration=FeatureGeneration(),
          problemDefinition=ProblemDefinition(),
          modelBuilding=ModelBuilding(),
          reporting=Reporting(),
          revision_description=None,
          learning_mode=None,
          parent_revision=None):
    validation.assert_type(user_session, UserSession)
    train_data = _wrap_with_data_input_if_needed(train_data, "Train")
    if test_data is not None:
        test_data = _wrap_with_data_input_if_needed(test_data, "Test")

    training_provider = _handle_data(project_name, user_session, train_data, preProcessing)
    test_provider = _handle_data(project_name, user_session, test_data, preProcessing) \
        if test_data is not None else (None, None)

    contexts = validation.wrap_with_list_if_needed(context_datasets)
    # if contexts is not None:
    remoteContexts = [
        _handle_context(project_name, user_session, c) for c in
        contexts] if contexts is not None else None

    if modelBuilding.algorithmsWhiteList is not None:
        algorithms_list = validation.wrap_with_list_if_needed(modelBuilding.algorithmsWhiteList)
        [validation.assert_type(alg, AlgorithmDefinition) for alg in algorithms_list]
        algorithms_without_hyper_params = [alg for alg in algorithms_list if not alg.hyper_params]
        algorithms_with_hyper_params = [alg for alg in algorithms_list if alg.hyper_params]
        algorithms_white_list = [alg.name for alg in algorithms_without_hyper_params]
    else:
        algorithms_with_hyper_params = []
        algorithms_white_list = None

    learning_job = user_session.create_learning_job(LearningParams(
        projectName=project_name,
        revisionDescription=revision_description,
        parentRevision=parent_revision,
        trainingProvider=training_provider,
        target=target,

        testProvider=test_provider,
        trainTestSplitRatio=problemDefinition.trainTestSplitRatio,
        contextDatasets=remoteContexts,
        weightColumn=problemDefinition.weightColumn,
        weightByClass=problemDefinition.weightByClass,
        timeWindowsDefinition=validation.wrap_with_list_if_needed(problemDefinition.time_windows_definition),
        emptyValuePolicy=preProcessing.emptyValuePolicy,
        fileEncoding=preProcessing.fileEncoding,
        temporalSplitColumn=problemDefinition.temporalSplitColumn,
        fileEscaping=preProcessing.fileEscaping,
        linesForTypeDetection=preProcessing.linesForTypeDetection,
        localTopFeatureCount=featureGeneration.localTopFeatureCount,
        supportThreshold=featureGeneration.minSupportAbsolute,
        maxDepth=featureGeneration.maxDepth,
        expandedTimeSeries=featureGeneration.expandedTimeSeries,
        featureSearchMode=featureGeneration.featureSearchMode,
        maxFeaturesCount=validation.wrap_with_list_if_needed(featureGeneration.maxFeaturesCount),
        functionsWhiteList=validation.wrap_with_list_if_needed(featureGeneration.functionsWhiteList),
        functionsBlackList=validation.wrap_with_list_if_needed(featureGeneration.functionsBlackList),
        booleanNumericFeatures=featureGeneration.booleanNumericFeatures,
        numericEqualityFeatures=featureGeneration.numericEqualityFeatures,
        equalityFeatures=featureGeneration.equalityFeatures,
        allowRangeFeatures=featureGeneration.allowRangeFeatures,
        customColumnSubsets=featureGeneration.customColumnSubsets,
        autoColumnSubSets=validation.wrap_with_list_if_needed(featureGeneration.autoColumnSubSets),
        useCachedFeatures=featureGeneration.useCachedFeatures,
        maxFeatureDuration=featureGeneration.maxFeatureDuration,
        overrideMaxFeatureDurationForExternalData=featureGeneration.overrideMaxFeatureDurationForExternalData,
        allocatedMemoryMB=featureGeneration.allocatedMemoryMB,
        maxCollectionSize=featureGeneration.maxCollectionSize,
        automaticSelectionOfNumberOfFeatures=featureGeneration.automaticSelectionOfNumberOfFeatures,
        regressionDiscretizerBinsOverride=validation.wrap_with_list_if_needed(featureGeneration.regressionDiscretizerBinsOverride),
        regressionNumberOfBins=featureGeneration.regressionNumberOfBins,
        useRawNumericColumns=featureGeneration.useRawNumericColumns,
        regressionMode=problemDefinition.forceRegression,
        linkedDataCore=knowledge.linked_data_core,
        openStreetMap=knowledge.open_street_map,
        weather=knowledge.weather,
        holidays=knowledge.holidays,
        algorithmsWhiteList=algorithms_white_list,
        extraModels=_to_hyper_params_settings(algorithms_with_hyper_params),
        evaluationMetric=modelBuilding.evaluationMetric,
        crossValidation=modelBuilding.crossValidation,
        validationSetRatio=modelBuilding.validationSetRatio,
        produceFeatureClusteringReport=reporting.featureClustersReport,
        scoreOnTestSet=reporting.scoreOnTestSet,
        emailForNotification=reporting.emailForNotification,
        partitionColumn=problemDefinition.partition_column,

        gainThreshold=featureGeneration.gainThreshold,
        timeVSQualityFactor=featureGeneration.timeVSQualityFactor,
        timeVSSmallSupportFactor=featureGeneration.timeVSSmallSupportFactor,
        deduplicationSimilarityThreshold=featureGeneration.deduplicationSimilarityThreshold,
        acceleratedFeatureSearch=featureGeneration.acceleratedFeatureSearch,
        learningMode=learning_mode
    ))

    job_status = user_session.get_learning_job_status(learning_job.job_id)
    if job_status.status is not LearningJobStatus.Statuses.FAILED:
        if reporting.showWebView:
            user_session.browse_revision(project_name, learning_job.revision)
    else:
        log.error("Failed to start the learning job")
    return learning_job


def relearn_with_new_inputs(user_session, project_name, inputs, revision=None, show_web_view=True):
    def handle_input(data_input):
        return _handle_data(project_name, user_session,
                            data=_wrap_with_data_input_if_needed(data_input, "Input"))

    inputs_on_server = {input_name: handle_input(input_local_path) for input_name, input_local_path in inputs.items()}

    input_providers = {input_name: input_provider for input_name, input_provider
                       in inputs_on_server.items() if input_provider}
    learning_job = user_session.create_learning_job_based_on_existing_pipeline(project_name,
                                                                               input_providers, revision)
    job_status = user_session.get_learning_job_status(learning_job.job_id)
    if job_status.status is not LearningJobStatus.Statuses.FAILED:
        if show_web_view:
            user_session.browse_revision(project_name, learning_job.revision)
    else:
        log.error("Failed to start the learning job")
    return learning_job


def get_inputs_structure(user_session, project_name, revision):
    return LearningDefinition(user_session.get_inputs_structure(project_name, revision))


def wait_for_learn_job_to_finish(user_session, project_name, revision, job_id,
                                 timeout_seconds=2*3600, polling_rate_seconds=5):
    validation.assert_type(user_session, UserSession)
    import time

    current_streaming_line = 0

    def current_time_seconds():
        return int(round(time.time()))

    def queued_status(queue_position):

        try:
            queued_jobs = user_session.show_jobs(status='queued')
        except Exception as e:
            log.error(e)
            queued_jobs = None
        if queued_jobs:
            current_position = queue_position
            for index, item in enumerate(queued_jobs):
                if item.job_id == job_id:
                    current_position = index
                    break

            if queue_position != current_position:
                log.info("LearningJob ({0}) position at the queue is {1}.".format(job_id, current_position + 1))
                queue_position = current_position
        return queue_position

    def running_status(streaming_line, shown_input_schema, shown_features):
        stream = ''
        try:
            stream = user_session.learn_streaming_api(project_name, revision, streaming_line)
        except Exception as e:
            log.error(e)

        lines_read = 0
        if stream:
            log.info(stream)
            lines_read = len(stream.split('\n'))

        streaming_line = streaming_line + lines_read

        def show_input_schema(session, current_project_name, current_revision):
            try:
                input_schema = get_inputs_structure(session, current_project_name, current_revision)
                input_schema.print_inputs_schema()
                return True
            except Exception:
                return False

        if not shown_input_schema:
            shown_input_schema = show_input_schema(user_session, project_name, revision)

        if not shown_features:
            learn_features = features(user_session, project_name, revision)
            if learn_features is not None:
                log.info(learn_features)
                shown_features = True
        return {
            'current_streaming_line': streaming_line,
            'has_shown_input_schema': shown_input_schema,
            'has_shown_features': shown_features
        }

    timeout_deadline = current_time_seconds() + timeout_seconds
    job_finished = False
    has_shown_input_schema = False
    has_shown_features = False
    last_queue_position = -1

    while not job_finished and current_time_seconds() < timeout_deadline:
        current_status = user_session.get_learning_job_status(job_id)
        log.debug('Current status: {0}'.format(current_status.status))
        if current_status.status == LearningJobStatus.Statuses.QUEUED:
            last_queue_position = queued_status(last_queue_position)
        elif current_status.status == LearningJobStatus.Statuses.RUNNING:
            ret_statuses = running_status(current_streaming_line, has_shown_input_schema, has_shown_features)
            current_streaming_line = ret_statuses['current_streaming_line']
            has_shown_input_schema = ret_statuses['has_shown_input_schema']
            has_shown_features = ret_statuses['has_shown_features']
        elif current_status.status == LearningJobStatus.Statuses.FAILED:
            log.error(current_status.error)
            job_finished = True
        elif current_status.status == LearningJobStatus.Statuses.CANCELED:
            log.error('Learning session was canceled')
            job_finished = True
        elif current_status.status == LearningJobStatus.Statuses.DONE:
            running_status(current_streaming_line, has_shown_input_schema, has_shown_features)
            evaluation_result = evaluate(user_session, project_name, revision)
            log.info(evaluation_result.summary)
            job_finished = True
        elif current_status.status == LearningJobStatus.Statuses.TERMINATED:
            log.info('Learning session was terminated')
            job_finished = True

        if not job_finished:
            time.sleep(polling_rate_seconds)

    return user_session.get_learning_job_status(job_id)


def evaluate(user_session, project_name, revision):
    validation.assert_type(user_session, UserSession)
    evaluation = user_session.get_model_evaluation(project_name, revision)
    return EvaluationResult(evaluation.evaluation_method,
                            evaluation.score,
                            evaluation.summary,
                            evaluation.details)


def features(user_session, project_name, revision):
    validation.assert_type(user_session, UserSession)
    return user_session.get_generated_features(project_name, revision)


def export_model_for_prediction(user_session, project_name, revision, include_contexts):
    exports = {}
    log.info("Downloading feature extractor")
    path = user_session.download_feature_extractor(project_name, revision)
    exports[ModelExports.FEATURE_EXTRACTOR] = path
    log.info("Successfully exported feature extractor to: %s", path)

    log.info("Downloading model")
    path = user_session.download_model(project_name, revision)
    exports[ModelExports.MODEL] = path
    log.info("Successfully exported model to: %s", path)

    if include_contexts:
        log.info("Downloading contexts")
        path = user_session.download_contexts(project_name, revision)
        exports[ModelExports.CONTEXTS] = path
        log.info("Successfully exported contexts to: %s", path)

    return exports


def export_model_to_prediction_box(
        user_session, project_name, revision,
        prediction_box_url, auth_key=None, upload_contexts=None,
        overwrite_existing=None, override_target_group_name=None):
    user_session.export_model_to_prediction_box(
        project_name=project_name, revision=revision,
        prediction_box_url=prediction_box_url, auth_key=auth_key,
        upload_contexts=upload_contexts,
        overwrite_existing=overwrite_existing, override_target_group_name=override_target_group_name
    )


def predict(user_session,
            project_name,
            revision,
            predict_data,
            include_originals,
            include_enriched,
            include_explanations,
            columns_white_list,
            lines_for_context_match_report,
            context_data,
            include_typer_error_report):
    validation.assert_type(user_session, UserSession)
    predict_data = _wrap_with_data_input_if_needed(predict_data)

    predict_provider = _handle_data(project_name, user_session, predict_data)

    contexts = [_handle_context(project_name, user_session, c) for c in
                context_data] if context_data is not None else None

    return user_session.predict(PredictParams(
        projectName=project_name,
        revision=revision,
        predictDataProvider=predict_provider,
        includeOriginals=include_originals,
        includeEnriched=include_enriched,
        includeExplanations=include_explanations,
        columnWhiteList=columns_white_list,
        linesForContextMatchReport=lines_for_context_match_report,
        contexts=contexts,
        includeTyperErrorReport=include_typer_error_report
    ))


def enrich(user_session,
           project_name,
           revision,
           enrich_data,
           feature_count=None,
           include_originals=None,
           column_white_list=None,
           lines_for_context_match_report=None,
           context_data=None,
           include_typer_error_report=None):
    validation.assert_type(user_session, UserSession)
    enrich_data = _wrap_with_data_input_if_needed(enrich_data)

    enrich_provider = _handle_data(project_name, user_session, enrich_data)

    contexts = [_handle_context(project_name, user_session, c) for c in
                context_data] if context_data is not None else None

    return user_session.enrich(EnrichParams(
        projectName=project_name,
        revision=revision,
        enrichDataProvider=enrich_provider,
        featureCount=feature_count,
        includeOriginals=include_originals,
        columnsWhiteList=column_white_list,
        linesForContextMatchReport=lines_for_context_match_report,
        contextDatasets=contexts,
        includeTyperErrorReport=include_typer_error_report
    ))


def web_view(user_session, project_name, revision):
    validation.assert_type(user_session, UserSession)
    user_session.browse_revision(project_name, revision)


def revision_web_link(user_session, project_name, revision):
    validation.assert_type(user_session, UserSession)
    return user_session.revision_web_link(project_name, revision)


def update_world_knowledge_objects(user_session):
    import pandas as pd
    import datetime

    def object_column_from_column_metadata(col_metadata):
        return world_knowledge.WorldKnowledgeObject.WorldKnowledgeObjectColumn(
            name=col_metadata.name, column_type=col_metadata.type)

    def object_context_from_context_metadata(context_metadata):
        return world_knowledge.WorldKnowledgeObject.WorldKnowledgeContext(
            key_columns=[object_column_from_column_metadata(col_metadata)
                         for col_metadata in context_metadata.key_columns],
            time_column=object_column_from_column_metadata(context_metadata.time_column) if context_metadata.time_column is not None else None,
            context_type=context_metadata.context_type
        )

    def object_from_metadata(ds_metadata):
        import math
        return world_knowledge.WorldKnowledgeObject(
            id=ds_metadata.name, name=ds_metadata.display_name,
            category=ds_metadata.category, description=ds_metadata.description,
            context=object_context_from_context_metadata(ds_metadata.context),
            rows=ds_metadata.rows, columns=ds_metadata.columns,
            size_mb=math.ceil(ds_metadata.size_bytes/1024.0/1024.0*100)/100,
            uploaded_by=ds_metadata.uploaded_by, updated_on=ds_metadata.updated_on,
            url=ds_metadata.url, user_session=user_session)

    validation.assert_type(user_session, UserSession)
    res = user_session.get_world_knowledge_objects_metadata()
    objects_metadata = res.objects_metadata
    objects = [object_from_metadata(obj_metadata) for obj_metadata in objects_metadata]

    columns = ['name', 'category', 'description', 'context_type', 'context_keys', 'context_time_column',
               'rows', 'columns', 'size_mb', 'uploaded_by', 'updated_on']
    df = pd.DataFrame(columns=columns)
    if objects:
        df = pd.DataFrame.from_dict(
            {objects.id: [
                objects.name, objects.category, objects.description,
                objects.context.context_type, objects.context.key_columns, objects.context.time_column,
                objects.rows, objects.columns, objects.size_mb,
                objects.uploaded_by, datetime.datetime.fromtimestamp(objects.updated_on / 1000.0)
            ] for objects in objects},
            orient='index')
        df.columns = columns
        df.index.name = 'ID'
    elif res.sync_failure:
        log.warn("Could not initialize World Knowledge due to the following error: {}".format(res.sync_failure['error']))

    return world_knowledge.WorldKnowledge(world_knowledge._ObjectsCollection(objects), df)


def get_inputs_schema(user_session, project_name, revision):
    return user_session.get_inputs_schema(project_name, revision)


def check_types(user_session, project_name, revision, input_name, data, typers, file_escaping, file_encoding,
                take_rows, examples_per_column):
    data = _wrap_with_data_input_if_needed(data)
    input_provider = _handle_data(project_name, user_session, data,
                                  PreProcessing(file_escaping=file_escaping,
                                                file_encoding=file_encoding))
    res = user_session.check_types(project_name, revision, input_name, input_provider, typers,
                                   take_rows, examples_per_column)

    log.info(_type_error_report.print_type_error_overview({'inputs': {input_name: res}}))
    return _type_error_report.generate_errors_data_frame(res)
